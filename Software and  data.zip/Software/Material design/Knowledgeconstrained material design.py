# -*- coding: utf-8 -*-
"""
Created on Thu Oct  2 15:12:19 2025

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Inverse Design - Only includes key components PP, PAPP, MPP, ADP, ZS, W
ADP fixed at 0.3
(Continuable version: supports interruption and resume, automatically continues csv & xlsx)
"""

import numpy as np, pandas as pd, joblib, warnings, os
from hyperopt import hp, tpe, fmin, Trials, STATUS_OK

warnings.filterwarnings('ignore')

# ---------- 1. Configuration ----------
TARGET_PHRR = 180
TARGET_T5   = 430
MAX_EVALS   = 15000
RESULTS_PATH= 'inverse_design_key_components.csv'   # csv history
RESULTS_XLSX= 'inverse_design_key_components.xlsx'   # excel final display

PHRR_MODEL  = 'phrr_model1.pkl'
PHRR_COLS   = 'phrr_train_features.pkl'     # 26 dimensions
STAB_MODEL  = 'stability_model.pkl'
SELECTED_CSV= 'selected_features.csv'

# ---------- 2. Loading ----------
phrr_model = joblib.load(PHRR_MODEL)
phrr_cols  = joblib.load(PHRR_COLS)

# PHRR subset
sel_idx = pd.read_csv(SELECTED_CSV)['feature_index'].values
sel_idx = [i for i in sel_idx if i < len(phrr_cols)]

stab_model = joblib.load(STAB_MODEL)

# ---------- 3. Utilities ----------
PP_MIN, PP_MAX = 60, 100
ADP_FIXED = 0.3  # ADP fixed at 0.3

# Key components list - only includes these components
KEY_COMPONENTS = ['PP', 'PAPP', 'MPP', 'ADP', 'ZS', 'W']

# Feature engineering function (consistent with training code)
def feature_engineering(p, target_col=None):
    """
    Create feature engineered feature vector from input dictionary p
    Consistent with feature engineering process in training code
    """
    # Create DataFrame
    df = pd.DataFrame({k: [v] for k, v in p.items()})

    # Feature enhancement based on numerical features (only process existing numerical columns)
    additive_cols = ['PAPP', 'MPP', 'W', 'ZS', 'ADP']
    existing_additive = [col for col in additive_cols if col in df.columns]
    if existing_additive:
        df['total_ad'] = df[existing_additive].sum(axis=1)
        # Calculate additive_ratio
        max_val = df[existing_additive].max(axis=1)
        df['additive_ratio'] = df['total_ad'] / (max_val + 1e-6)
    else:
        df['total_ad'] = 0
        df['additive_ratio'] = 0

    # Numerical feature ratio calculation
    if 'PAPP' in df.columns and 'total_ad' in df.columns:
        df['PAPP_ratio'] = df['PAPP'] / (df['total_ad'] + 1e-6)
    else:
        df['PAPP_ratio'] = 0

    if 'MPP' in df.columns and 'total_ad' in df.columns:
        df['MPP_ratio'] = df['MPP'] / (df['total_ad'] + 1e-6)
    else:
        df['MPP_ratio'] = 0

    # Synergist numerical feature processing
    synergist_cols = ['W', 'ZS', 'ADP']
    existing_synergist = [col for col in synergist_cols if col in df.columns]
    if existing_synergist:
        df['synergist_total'] = df[existing_synergist].sum(axis=1)
        if 'W' in df.columns:
            df['W_ratio_in_synergist'] = df['W'] / (df['synergist_total'] + 1e-6)
        else:
            df['W_ratio_in_synergist'] = 0
    else:
        df['synergist_total'] = 0
        df['W_ratio_in_synergist'] = 0

    # Numerical feature interaction terms
    if all(col in df.columns for col in ['PAPP', 'MPP', 'W']):
        df['PAPP_MPP_W_interaction'] = df['PAPP'] * df['MPP'] * df['W']
    else:
        df['PAPP_MPP_W_interaction'] = 0

    # Numerical feature squared terms
    if 'PAPP' in df.columns:
        df['PAPP_square'] = df['PAPP'] ** 2
    else:
        df['PAPP_square'] = 0

    if 'MPP' in df.columns:
        df['MPP_square'] = df['MPP'] ** 2
    else:
        df['MPP_square'] = 0

    # Add more feature interactions and transformations
    if all(col in df.columns for col in ['PAPP', 'MPP']):
        df['PAPP_MPP_ratio'] = df['PAPP'] / (df['MPP'] + 1e-6)
    else:
        df['PAPP_MPP_ratio'] = 0

    if all(col in df.columns for col in ['PAPP', 'W']):
        df['PAPP_W_ratio'] = df['PAPP'] / (df['W'] + 1e-6)
    else:
        df['PAPP_W_ratio'] = 0

    # Add polynomial features
    if 'PAPP' in df.columns:
        df['PAPP_sqrt'] = np.sqrt(df['PAPP'])
    else:
        df['PAPP_sqrt'] = 0

    if 'MPP' in df.columns:
        df['MPP_sqrt'] = np.sqrt(df['MPP'])
    else:
        df['MPP_sqrt'] = 0

    # Add more ratio features
    if all(col in df.columns for col in ['ZS', 'total_ad']):
        df['ZS_ratio'] = df['ZS'] / (df['total_ad'] + 1e-6)
    else:
        df['ZS_ratio'] = 0

    if all(col in df.columns for col in ['W', 'total_ad']):
        df['W_ratio'] = df['W'] / (df['total_ad'] + 1e-6)
    else:
        df['W_ratio'] = 0
    if all(col in df.columns for col in ['ADP', 'total_ad']):
        df['ADP_ratio'] = df['ADP'] / (df['total_ad'] + 1e-6)
    else:
        df['ADP_ratio'] = 0
    # Ensure all features used during training exist
    for feat in phrr_cols:
        if feat not in df.columns and feat != target_col:
            df[feat] = 0

    # Return feature engineered vector (features only, no target column)
    if target_col and target_col in df.columns:
        df = df.drop(columns=[target_col])

    return df

# PHRR prediction function (using feature engineering)
def predict_phrr(p):
    # Apply feature engineering
    df_eng = feature_engineering(p)

    # Ensure feature order is consistent with training
    x = np.zeros(len(phrr_cols))
    for i, feat in enumerate(phrr_cols):
        if feat in df_eng.columns:
            x[i] = df_eng[feat].iloc[0]
        else:
            x[i] = 0.0

    # Apply feature selection
    x = np.array([x])[:, sel_idx]

    # Ensure feature count matches
    if x.shape[1] != phrr_model.n_features_in_:
        x = x[:, :phrr_model.n_features_in_]

    return float(phrr_model.predict(x)[0])

# T5% prediction function
def predict_t5(p):
    # Since T5% model requires 12 features, but we only use key components
    # We need to create a vector with 12 zeros, then place key component values in correct positions

    # T5_COLS_ORDER is fixed
    T5_COLS_ORDER = ['PP', 'AAPP', '纤维', 'APP', 'HBPPA-Si',
                     '木粉', 'PAPP', 'LDH', 'W', 'MAPP',
                     'Foam agent', 'Sb2O3']

    # Create vector, initialized to 0
    vec = [0.0] * 12

    # Place key component values in correct positions
    for i, col in enumerate(T5_COLS_ORDER):
        if col in p:
            vec[i] = p[col]

    # Ensure PP is within reasonable range
    vec[0] = max(PP_MIN, min(PP_MAX, vec[0]))  # PP

    vec = np.array([vec], dtype=np.float64)

    # Ensure feature count matches
    if vec.shape[1] != stab_model.n_features_in_:
        vec = vec[:, :stab_model.n_features_in_]

    return float(stab_model.predict(vec)[0])

# ---------- 4. Continuation: Load History ----------
def load_history():
    """Return historical DataFrame + set of already evaluated {parameter tuple}"""
    if not os.path.exists(RESULTS_PATH):
        return pd.DataFrame(), set()
    hist = pd.read_csv(RESULTS_PATH)
    # Use parameter tuple as unique key
    param_keys = set()
    for _, row in hist.iterrows():
        tup = tuple(round(row[k], 4) for k in ['PP', 'PAPP', 'MPP', 'ZS', 'W'])
        param_keys.add(tup)
    return hist, param_keys

history_df, DONE_KEYS = load_history()

# ---------- 5. Optimization ----------
def run_search(ph_target, t5_target, max_evals):
    global history_df, DONE_KEYS
    new_rows = []   # New records obtained only in this run

    # Optimization space - only includes key components (ADP fixed at 0.3, not participating in optimization)
    space = {
        'PP': hp.uniform('PP', PP_MIN, PP_MAX),
        'PAPP': hp.uniform('PAPP', 0, 24),
        'MPP': hp.uniform('MPP', 0, 14),
        'ZS': hp.uniform('ZS', 0, 1.6),
        'W': hp.uniform('W', 2.5, 9)
    }

    def obj(opt):
        # Quick duplicate check
        tup = tuple(round(opt[k], 4) for k in ['PP', 'PAPP', 'MPP', 'ZS', 'W'])
        if tup in DONE_KEYS:
            # Directly return historical loss
            row = history_df[(history_df['PP'].round(4) == tup[0]) &
                             (history_df['PAPP'].round(4) == tup[1]) &
                             (history_df['MPP'].round(4) == tup[2]) &
                             (history_df['ZS'].round(4) == tup[3]) &
                             (history_df['W'].round(4) == tup[4])]
            return {'loss': row.iloc[0]['loss'], 'status': STATUS_OK}

        # New sample
        opt_sum = sum(opt.values())
        if opt_sum + ADP_FIXED > 100:
            return {'loss': 9999, 'status': STATUS_OK}
        p = opt.copy()
        p['ADP'] = ADP_FIXED
        p['PP']  = max(PP_MIN, min(PP_MAX, p['PP']))
        ph = predict_phrr(p)
        t5 = predict_t5(p)
        loss = abs(ph - ph_target)/ph_target + abs(t5 - t5_target)/t5_target
        rec = {**p, 'phrr_pred': ph, 't5_pred': t5, 'loss': loss}
        new_rows.append(rec)
        DONE_KEYS.add(tup)
        return {'loss': loss, 'status': STATUS_OK}

    # Calculate how many more runs are needed
    already = len(history_df)
    need    = max_evals - already
    if need > 0:
        fmin(fn=obj, space=space, algo=tpe.suggest, max_evals=need,
             trials=Trials(), show_progressbar=True)
        # Append to csv
        if new_rows:
            pd.DataFrame(new_rows).to_csv(RESULTS_PATH, mode='a',
                                          header=not os.path.exists(RESULTS_PATH),
                                          index=False, encoding='utf-8-sig')
    # Re-read complete history
    history_df = pd.read_csv(RESULTS_PATH)
    # Remove duplicates and sort
    history_df = history_df.drop_duplicates(subset=['PP', 'PAPP', 'MPP', 'ZS', 'W'])
    # Write to excel
    history_df.to_excel(RESULTS_XLSX, index=False)
    return history_df.nsmallest(4, 'loss').to_dict('records')

# ---------- 6. Main ----------
if __name__ == '__main__':
    print('='*60, 'Inverse Design (Only includes key components PP,PAPP,MPP,ADP,ZS,W, ADP fixed at 0.3)', '='*60)

    # Perform optimization directly
    best = run_search(TARGET_PHRR, TARGET_T5, MAX_EVALS)

    # Output best formulations
    for i, r in enumerate(best, 1):
        print(f'\nFormulation {i}')
        # Output all key components
        total = 0
        for comp in KEY_COMPONENTS:
            print(f'  {comp}: {r[comp]:.2f}')
            if comp != 'PP':  # PP is matrix, not counted in additives
                total += r[comp]

        print(f'  Total additives: {total:.2f}')
        print(f'  PP content: {r["PP"]:.2f}')
        print(f'  Total content: {total + r["PP"]:.2f}')
        print(f'  PHRR={r["phrr_pred"]:.1f} | T5%={r["t5_pred"]:.1f}')