# -*- coding: utf-8 -*-
"""
Created on Thu Oct  2 15:34:00 2025

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Sep 24 18:49:36 2025

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Unconstrained Inverse Design - For generating benchmark comparison data
Ensures generation of results with flame retardants at 0, representing true unconstrained search
"""

import numpy as np, pandas as pd, joblib, warnings, os
from hyperopt import hp, tpe, fmin, Trials, STATUS_OK
import time

warnings.filterwarnings('ignore')

# ---------- 1. Configuration ----------
TARGET_PHRR = 180
TARGET_T5   = 430
MAX_EVALS   = 7500
RESULTS_PATH= 'unconstrained_design_results_final.csv'
RESULTS_XLSX= 'unconstrained_design_results_final.xlsx'

PHRR_MODEL  = 'phrr_model1.pkl'
PHRR_COLS   = 'phrr_train_features.pkl'
STAB_MODEL  = 'stability_model.pkl'
SELECTED_CSV= 'selected_features.csv'

# ---------- 2. Load Models ----------
phrr_model = joblib.load(PHRR_MODEL)
phrr_cols  = joblib.load(PHRR_COLS)

sel_idx = pd.read_csv(SELECTED_CSV)['feature_index'].values
sel_idx = [i for i in sel_idx if i < len(phrr_cols)]

stab_model = joblib.load(STAB_MODEL)

# ---------- 3. True Unconstrained Search Space ----------
# Key modification: allow all components to start from 0, including flame retardants
SPACE_UNCONSTRAINED = {
    'PP': hp.uniform('PP', 20, 95),        # Larger PP range, allowing high content
    'PAPP': hp.uniform('PAPP', 0, 50),     # Explicitly starting from 0
    'MPP': hp.uniform('MPP', 0, 50),       # Explicitly starting from 0
    'ZS': hp.uniform('ZS', 0, 30),         # Explicitly starting from 0
    'W': hp.uniform('W', 0, 25),           # Explicitly starting from 0
    'ADP': hp.uniform('ADP', 0, 8),        # Explicitly starting from 0
    'APP': hp.uniform('APP', 0, 40),       # Explicitly starting from 0
    'AAPP': hp.uniform('AAPP', 0, 40),     # Explicitly starting from 0
    'GNP': hp.uniform('GNP', 0, 15),       # Explicitly starting from 0
    'Clay': hp.uniform('Clay', 0, 15),     # Explicitly starting from 0
    'DBDE': hp.uniform('DBDE', 0, 30)      # Added DBDE, starting from 0
}

# All possible components
ALL_COMPONENTS = ['PP', 'PAPP', 'MPP', 'ADP', 'ZS', 'W', 'APP', 'AAPP', 'GNP', 'Clay', 'DBDE']

# Flame retardants list (these components can be zero)
FLAME_RETARDANTS = ['PAPP', 'MPP', 'APP', 'AAPP', 'DBDE']

# ---------- 4. Feature Engineering Function (unchanged) ----------
def feature_engineering(p, target_col=None):
    """Same feature engineering as constrained version"""
    df = pd.DataFrame({k: [v] for k, v in p.items()})

    # Feature enhancement based on numerical features
    additive_cols = ['PAPP', 'MPP', 'W', 'ZS', 'ADP', 'APP', 'AAPP', 'DBDE']
    existing_additive = [col for col in additive_cols if col in df.columns]
    if existing_additive:
        df['total_ad'] = df[existing_additive].sum(axis=1)
        max_val = df[existing_additive].max(axis=1)
        df['additive_ratio'] = df['total_ad'] / (max_val + 1e-6)
    else:
        df['total_ad'] = 0
        df['additive_ratio'] = 0

    # Numerical feature ratio calculation (handling possible 0 cases)
    if 'PAPP' in df.columns and 'total_ad' in df.columns and df['total_ad'].iloc[0] > 0:
        df['PAPP_ratio'] = df['PAPP'] / (df['total_ad'] + 1e-6)
    else:
        df['PAPP_ratio'] = 0

    if 'MPP' in df.columns and 'total_ad' in df.columns and df['total_ad'].iloc[0] > 0:
        df['MPP_ratio'] = df['MPP'] / (df['total_ad'] + 1e-6)
    else:
        df['MPP_ratio'] = 0

    # Synergist numerical feature processing
    synergist_cols = ['W', 'ZS', 'ADP']
    existing_synergist = [col for col in synergist_cols if col in df.columns]
    if existing_synergist and df[existing_synergist].sum(axis=1).iloc[0] > 0:
        df['synergist_total'] = df[existing_synergist].sum(axis=1)
        if 'W' in df.columns:
            df['W_ratio_in_synergist'] = df['W'] / (df['synergist_total'] + 1e-6)
        else:
            df['W_ratio_in_synergist'] = 0
    else:
        df['synergist_total'] = 0
        df['W_ratio_in_synergist'] = 0

    # Numerical feature interaction terms (handling possible 0 cases)
    if all(col in df.columns for col in ['PAPP', 'MPP', 'W']):
        df['PAPP_MPP_W_interaction'] = df['PAPP'] * df['MPP'] * df['W']
    else:
        df['PAPP_MPP_W_interaction'] = 0

    # Numerical feature squared terms
    if 'PAPP' in df.columns:
        df['PAPP_square'] = df['PAPP'] ** 2
    else:
        df['PAPP_square'] = 0

    if 'MPP' in df.columns:
        df['MPP_square'] = df['MPP'] ** 2
    else:
        df['MPP_square'] = 0

    # More feature interactions (handling division by zero)
    if all(col in df.columns for col in ['PAPP', 'MPP']) and df['MPP'].iloc[0] > 0:
        df['PAPP_MPP_ratio'] = df['PAPP'] / (df['MPP'] + 1e-6)
    else:
        df['PAPP_MPP_ratio'] = 0

    if all(col in df.columns for col in ['PAPP', 'W']) and df['W'].iloc[0] > 0:
        df['PAPP_W_ratio'] = df['PAPP'] / (df['W'] + 1e-6)
    else:
        df['PAPP_W_ratio'] = 0

    # Polynomial features
    if 'PAPP' in df.columns and df['PAPP'].iloc[0] >= 0:
        df['PAPP_sqrt'] = np.sqrt(max(0, df['PAPP'].iloc[0]))
    else:
        df['PAPP_sqrt'] = 0

    if 'MPP' in df.columns and df['MPP'].iloc[0] >= 0:
        df['MPP_sqrt'] = np.sqrt(max(0, df['MPP'].iloc[0]))
    else:
        df['MPP_sqrt'] = 0

    # More ratio features
    if all(col in df.columns for col in ['ZS', 'total_ad']) and df['total_ad'].iloc[0] > 0:
        df['ZS_ratio'] = df['ZS'] / (df['total_ad'] + 1e-6)
    else:
        df['ZS_ratio'] = 0

    if all(col in df.columns for col in ['W', 'total_ad']) and df['total_ad'].iloc[0] > 0:
        df['W_ratio'] = df['W'] / (df['total_ad'] + 1e-6)
    else:
        df['W_ratio'] = 0
        
    if all(col in df.columns for col in ['ADP', 'total_ad']) and df['total_ad'].iloc[0] > 0:
        df['ADP_ratio'] = df['ADP'] / (df['total_ad'] + 1e-6)
    else:
        df['ADP_ratio'] = 0

    # Ensure all features used during training exist
    for feat in phrr_cols:
        if feat not in df.columns and feat != target_col:
            df[feat] = 0

    if target_col and target_col in df.columns:
        df = df.drop(columns=[target_col])

    return df

# ---------- 5. Prediction Functions ----------
def predict_phrr(p):
    """PHRR prediction function, handling flame retardants at 0"""
    try:
        df_eng = feature_engineering(p)
        x = np.zeros(len(phrr_cols))
        for i, feat in enumerate(phrr_cols):
            if feat in df_eng.columns:
                x[i] = df_eng[feat].iloc[0]
            else:
                x[i] = 0.0

        x = np.array([x])[:, sel_idx]
        if x.shape[1] != phrr_model.n_features_in_:
            x = x[:, :phrr_model.n_features_in_]

        return float(phrr_model.predict(x)[0])
    except Exception as e:
        print(f"PHRR prediction error: {e}")
        return 1000.0  # Return a higher default value

def predict_t5(p):
    """T5% prediction function, handling flame retardants at 0"""
    try:
        T5_COLS_ORDER = ['PP', 'AAPP', 'Fiber', 'APP', 'HBPPA-Si',
                         'Wood flour', 'PAPP', 'LDH', 'W', 'MAPP',
                         'Foam agent', 'Sb2O3']

        vec = [0.0] * 12
        for i, col in enumerate(T5_COLS_ORDER):
            if col in p:
                vec[i] = p[col]

        vec = np.array([vec], dtype=np.float64)
        if vec.shape[1] != stab_model.n_features_in_:
            vec = vec[:, :stab_model.n_features_in_]

        return float(stab_model.predict(vec)[0])
    except Exception as e:
        print(f"T5% prediction error: {e}")
        return 300.0  # Return a reasonable default value

# ---------- 6. Improved Unconstrained Optimization Function ----------
def run_unconstrained_search(ph_target, t5_target, max_evals):
    """Run true unconstrained inverse design"""
    all_results = []
    start_time = time.time()
    evaluation_count = 0
    
    def objective(params):
        # 1% probability to generate completely random parameters (ensuring coverage of 0 values)
        if np.random.random() < 0.01:
            for key in params:
                if key != 'PP':  # Keep PP relatively normal
                    params[key] = np.random.uniform(0, 50)  # Completely random, including 0
        nonlocal evaluation_count
        evaluation_count += 1
        
        if evaluation_count % 500 == 0:
            print(f"Evaluated {evaluation_count}/{max_evals} formulations")
        
        # Calculate total content
        total = sum(params.values())
        
        # Relaxed total constraint (allowing some degree of excess)
        if total > 105:  # Slightly more relaxed
            penalty = (total - 100) * 5  # Reduced penalty coefficient
            return {'loss': 5000 + penalty, 'status': STATUS_OK}
        
        try:
            ph_pred = predict_phrr(params)
            t5_pred = predict_t5(params)
            
            # Calculate loss function
            loss = (abs(ph_pred - ph_target) / ph_target + 
                   abs(t5_pred - t5_target) / t5_target)
            
            # Record result
            result = {
                **params,
                'phrr_pred': ph_pred,
                't5_pred': t5_pred,
                'loss': loss,
                'total_composition': total,
                'has_flame_retardant': any(params[fr] > 0.1 for fr in FLAME_RETARDANTS)  # Mark if contains flame retardant
            }
            all_results.append(result)
            
            return {'loss': loss, 'status': STATUS_OK}
            
        except Exception as e:
            print(f"Evaluation error: {e}")
            return {'loss': 9999, 'status': STATUS_OK}
    
    print("Starting true unconstrained inverse design...")
    print("Allowing flame retardant content at 0, simulating completely unconstrained search")
    
    best = fmin(
        fn=objective,
        space=SPACE_UNCONSTRAINED,
        algo=tpe.suggest,
        max_evals=max_evals,
        trials=Trials(),
        show_progressbar=True,
        verbose=False
    )
    
    # Save all results
    if all_results:
        df_results = pd.DataFrame(all_results)
        
        # Analyze formulations with flame retardants at 0
        no_retardant_count = len(df_results[~df_results['has_flame_retardant']])
        retardant_count = len(df_results[df_results['has_flame_retardant']])
        
        print(f"\n=== Formulation Statistics ===")
        print(f"Total candidates: {len(df_results)}")
        print(f"Formulations without flame retardants: {no_retardant_count} ({no_retardant_count/len(df_results)*100:.1f}%)")
        print(f"Formulations with flame retardants: {retardant_count} ({retardant_count/len(df_results)*100:.1f}%)")
        
        # Save results
        df_results.to_csv(RESULTS_PATH, index=False, encoding='utf-8-sig')
        df_results.to_excel(RESULTS_XLSX, index=False)
        
        print(f"\nCompleted! Generated {len(df_results)} candidate formulations")
        print(f"Time taken: {time.time()-start_time:.1f} seconds")
        
        # Display representative formulations
        print("\n=== Representative Formulation Examples ===")
        
        # 1. Best performance formulations
        best_df = df_results.nsmallest(3, 'loss')
        print("\n1. Best performing formulations:")
        for i, (_, row) in enumerate(best_df.iterrows(), 1):
            print(f"   Formulation{i}: Loss={row['loss']:.4f}, PHRR={row['phrr_pred']:.1f}, T5%={row['t5_pred']:.1f}")
            print(f"   Flame retardants: {['No' if not row['has_flame_retardant'] else 'Yes'][0]}")
        
        # 2. Formulations without flame retardants
        no_retardant_df = df_results[~df_results['has_flame_retardant']]
        if len(no_retardant_df) > 0:
            best_no_retardant = no_retardant_df.nsmallest(2, 'loss')
            print("\n2. Best formulations without flame retardants:")
            for i, (_, row) in enumerate(best_no_retardant.iterrows(), 1):
                print(f"   Formulation{i}: Loss={row['loss']:.4f}, PHRR={row['phrr_pred']:.1f}, T5%={row['t5_pred']:.1f}")
                print(f"   PP={row['PP']:.1f}%, Other additives total={row['total_composition']-row['PP']:.1f}%")
        
        # 3. Extreme formulation examples
        high_pp_df = df_results.nlargest(2, 'PP')
        print("\n3. High PP content formulation examples:")
        for i, (_, row) in enumerate(high_pp_df.iterrows(), 1):
            print(f"   Formulation{i}: PP={row['PP']:.1f}%, PHRR={row['phrr_pred']:.1f}")
        
        return df_results
    else:
        print("No results generated")
        return pd.DataFrame()

# ---------- 7. Detailed Statistical Analysis ----------
def analyze_results_detailed():
    """Detailed analysis of unconstrained design results"""
    if not os.path.exists(RESULTS_PATH):
        print("No results file")
        return
    
    df = pd.read_csv(RESULTS_PATH)
    print(f"\n=== Detailed Results Analysis ===")
    print(f"Total candidates: {len(df)}")
    
    # Basic statistics
    print(f"\n1. Performance Statistics:")
    print(f"   PHRR prediction range: {df['phrr_pred'].min():.1f} - {df['phrr_pred'].max():.1f}")
    print(f"   T5% prediction range: {df['t5_pred'].min():.1f} - {df['t5_pred'].max():.1f}")
    print(f"   Loss range: {df['loss'].min():.4f} - {df['loss'].max():.4f}")
    
    # Component statistics
    print(f"\n2. Component Statistics:")
    for comp in ALL_COMPONENTS:
        if comp in df.columns:
            non_zero = (df[comp] > 0.1).sum()  # >0.1% considered present
            zero_count = (df[comp] <= 0.1).sum()
            avg_val = df[comp][df[comp] > 0.1].mean() if non_zero > 0 else 0
            print(f"   {comp}: appears {non_zero} times({non_zero/len(df)*100:.1f}%), "
                  f"zero {zero_count} times({zero_count/len(df)*100:.1f}%), "
                  f"average content {avg_val:.1f}%")
    
    # Flame retardant statistics
    print(f"\n3. Flame Retardant Statistics:")
    no_retardant = len(df[~df['has_flame_retardant']])
    with_retardant = len(df[df['has_flame_retardant']])
    print(f"   Formulations without flame retardants: {no_retardant} ({no_retardant/len(df)*100:.1f}%)")
    print(f"   Formulations with flame retardants: {with_retardant} ({with_retardant/len(df)*100:.1f}%)")
    
    # Total content statistics
    print(f"\n4. Total Content Statistics:")
    print(f"   Average total content: {df['total_composition'].mean():.1f}%")
    print(f"   Total content range: {df['total_composition'].min():.1f}% - {df['total_composition'].max():.1f}%")
    print(f"   Formulations with total content >100%: {(df['total_composition'] > 100).sum()}")

# ---------- 8. Main Function ----------
if __name__ == '__main__':
    print('='*60)
    print('True Unconstrained Inverse Design - Allowing Flame Retardants at 0')
    print('='*60)
    
    # Run unconstrained search
    results_df = run_unconstrained_search(TARGET_PHRR, TARGET_T5, MAX_EVALS)
    
    # Detailed analysis of results
    analyze_results_detailed()