# -*- coding: utf-8 -*-
"""
Created on Thu Oct  2 13:50:06 2025

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Sep  9 11:00:28 2025

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
5-fold cross-validation model evaluation program (numerical features only) - non-standardized version
Improved version: Ensure model performance R² ≥ 0.7 and accuracy ≥ 85%, and prevent overfitting
Remove SVR model to avoid direct use of validation set for model selection
Add output functionality for 5-fold predictions and test set predictions
"""

import numpy as np
import pandas as pd
import joblib  
import os       
from datetime import datetime  
from sklearn.preprocessing import RobustScaler
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score, KFold, cross_val_predict
from sklearn.metrics import r2_score, mean_squared_error  
from scipy.stats import pearsonr  
from sklearn.linear_model import Ridge, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, AdaBoostRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
from xgboost import XGBRegressor
from catboost import CatBoostRegressor
import matplotlib.pyplot as plt
import warnings
from deap import base, tools, creator, algorithms
import random
import time  
from pathlib import Path
from sklearn.base import clone

warnings.filterwarnings('ignore')
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# -------------------------- Initialize experiment directory --------------------------
def init_experiment_dir():
    experiment_time = datetime.now().strftime("%Y%m%d_%H%M%S")
    experiment_dir = f"PHRR_experiment_{experiment_time}"
    os.makedirs(experiment_dir, exist_ok=True)
    os.makedirs(os.path.join(experiment_dir, "models"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "data_splits"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "feature_selection"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "scalers"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "logs"), exist_ok=True)  
    os.makedirs(os.path.join(experiment_dir, "predictions"), exist_ok=True)  # New prediction results directory
    return experiment_dir

# -------------------------- 1. Data loading (keep only numerical features, remove one-hot encoding) --------------------------
def load_data(random_seed):
    dataset = pd.read_excel("PHRRa1.xlsx")
    target_col = 'PHRR（Kw/m2）'
    
    # Remove NO sequence column
    if 'NO' in dataset.columns:
        initial_count = len(dataset)
        dataset = dataset.drop(columns=['NO'], errors='ignore')
        print(f"⚠️ NO sequence column detected, removed (original sample count: {initial_count}, after removal: {len(dataset)})")
    else:
        print(f"Original data sample count: {len(dataset)}")
    
    # Target value range filtering
    clean_mask = (dataset[target_col] > 10) & (dataset[target_col] <= 1000)
    dataset = dataset[clean_mask].copy().reset_index(drop=True)
    print(f"Sample count after target value filtering: {len(dataset)}")
    
    # Keep only numerical features (remove all non-numerical columns, no one-hot encoding needed)
    numeric_cols = dataset.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numeric_cols:
        numeric_cols.remove(target_col)
    # Filter non-numerical columns (completely remove matrix and other categorical columns)
    dataset = dataset[numeric_cols + [target_col]].copy()
    print(f"Only numerical features kept, feature list: {numeric_cols}")
    
    # IQR outlier filtering (only for numerical features)
    pre_iqr_count = len(dataset)
    for col in numeric_cols:
        Q1 = dataset[col].quantile(0.25)
        Q3 = dataset[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        dataset = dataset[(dataset[col] >= lower_bound) & (dataset[col] <= upper_bound)].copy().reset_index(drop=True)
    
    print(f"Sample count after IQR outlier filtering: {len(dataset)} (filtered out {pre_iqr_count - len(dataset)} outlier samples)")
    
    # Numerical feature missing value imputation (median)
    dataset[numeric_cols] = dataset[numeric_cols].fillna(dataset[numeric_cols].median())
    
    # No one-hot encoding, return empty matrix_cols and encoder
    return dataset, target_col, numeric_cols, [], None  

def load_validation_data(train_numeric_cols, train_matrix_cols=None, encoder=None):
    try:
        validation_data = pd.read_excel("留出做实验验证的样本.xlsx")
        target_col = 'PHRR（Kw/m2）'
        
        # Remove NO sequence column
        if 'NO' in validation_data.columns:
            initial_val_count = len(validation_data)
            validation_data = validation_data.drop(columns=['NO'], errors='ignore')
            print(f"⚠️ Validation set detected NO sequence column, removed (original validation sample count: {initial_val_count}, after removal: {len(validation_data)})")
        else:
            print(f"Loaded independent validation set data: {len(validation_data)} samples")
        
        # Target value range filtering
        validation_data = validation_data[(validation_data[target_col] > 10) & (validation_data[target_col] <= 1000)].copy()
        
        # Keep only numerical features (consistent with training set, no one-hot encoding)
        numeric_cols = validation_data.select_dtypes(include=[np.number]).columns.tolist()
        if target_col in numeric_cols:
            numeric_cols.remove(target_col)
        # Ensure validation set features match training set numerical features
        required_cols = train_numeric_cols + [target_col]
        missing_cols = [col for col in required_cols if col not in validation_data.columns]
        for col in missing_cols:
            validation_data[col] = 0  # Missing features filled with 0 (only numerical features)
        validation_data = validation_data[required_cols].copy()
        
        return validation_data
    except FileNotFoundError:
        print("Warning: Validation set file not found, will only use 5-fold cross-validation for model evaluation")
        return None
    except Exception as e:
        print(f"Error loading validation set: {str(e)}")
        return None

# -------------------------- 2. Feature engineering (enhanced version) --------------------------
def feature_engineering(data, target_col, train_features=None):
    df = data.copy()
    
    # Remove NO column (if exists)
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    
    # Feature enhancement based on numerical features (only process existing numerical columns)
    additive_cols = ['PAPP', 'MPP', 'W', 'ZS', 'ADP']
    existing_additive = [col for col in additive_cols if col in df.columns]
    if existing_additive:
        df['total_ad'] = df[existing_additive].sum(axis=1)
        # Remove matrix_sum calculation related to one-hot encoding, keep only numerical feature interactions
        df['additive_ratio'] = df['total_ad'] / (df[existing_additive].max(axis=1) + 1e-6)  # Replace with numerical feature max normalization
    else:
        df['total_ad'] = 0
        df['additive_ratio'] = 0
        print("⚠️ Core additive features (PAPP/MPP/W/ZS/ADP) do not exist, skipping related feature enhancement")
    
    # Numerical feature ratio calculation
    if 'PAPP' in df.columns and 'total_ad' in df.columns:
        df['PAPP_ratio'] = df['PAPP'] / (df['total_ad'] + 1e-6)
    else:
        df['PAPP_ratio'] = 0
    
    if 'MPP' in df.columns and 'total_ad' in df.columns:
        df['MPP_ratio'] = df['MPP'] / (df['total_ad'] + 1e-6)
    else:
        df['MPP_ratio'] = 0
    
    # Synergist numerical feature processing
    synergist_cols = ['W', 'ZS', 'ADP']
    existing_synergist = [col for col in synergist_cols if col in df.columns]
    if existing_synergist:
        df['synergist_total'] = df[existing_synergist].sum(axis=1)
        if 'W' in df.columns:
            df['W_ratio_in_synergist'] = df['W'] / (df['synergist_total'] + 1e-6)
        else:
            df['W_ratio_in_synergist'] = 0
    else:
        df['synergist_total'] = 0
        df['W_ratio_in_synergist'] = 0
    
    # Numerical feature interaction terms
    if all(col in df.columns for col in ['PAPP', 'MPP', 'W']):
        df['PAPP_MPP_W_interaction'] = df['PAPP'] * df['MPP'] * df['W']
    else:
        df['PAPP_MPP_W_interaction'] = 0
    
    # Numerical feature squared terms
    if 'PAPP' in df.columns:
        df['PAPP_square'] = df['PAPP'] ** 2
    else:
        df['PAPP_square'] = 0
    
    if 'MPP' in df.columns:
        df['MPP_square'] = df['MPP'] ** 2
    else:
        df['MPP_square'] = 0
    
    # Add more feature interactions and transformations
    if all(col in df.columns for col in ['PAPP', 'MPP']):
        df['PAPP_MPP_ratio'] = df['PAPP'] / (df['MPP'] + 1e-6)
    
    if all(col in df.columns for col in ['PAPP', 'W']):
        df['PAPP_W_ratio'] = df['PAPP'] / (df['W'] + 1e-6)
    
    # Add polynomial features
    if 'PAPP' in df.columns:
        df['PAPP_sqrt'] = np.sqrt(df['PAPP'])
    
    if 'MPP' in df.columns:
        df['MPP_sqrt'] = np.sqrt(df['MPP'])
    
    if all(col in df.columns for col in ['ZS', 'total_ad']):
        df['ZS_ratio'] = df['ZS'] / (df['total_ad'] + 1e-6)
    
    if all(col in df.columns for col in ['W', 'total_ad']):
        df['W_ratio'] = df['W'] / (df['total_ad'] + 1e-6)
    if all(col in df.columns for col in ['ADP', 'total_ad']):
        df['ADP_ratio'] = df['ADP'] / (df['total_ad'] + 1e-6)
    # Keep only numerical features
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if target_col in numeric_cols:
        numeric_cols.remove(target_col)
    
    # Align with training set features (only numerical features)
    if train_features is not None:
        train_features = [f for f in train_features if f != 'NO' and f in numeric_cols + [target_col]]
        for feat in train_features:
            if feat not in df.columns:
                df[feat] = 0
        df = df[train_features + [target_col]] if target_col in df.columns else df[train_features]
    
    return df

# -------------------------- 3. GA feature selection (optimized version) --------------------------
def ga_feature_selection(X, y, feature_names, core_features=["PAPP", "MPP", "W", "ZS", "ADP", "total_ad"], 
                         experiment_dir=None, random_seed=None):
    # Keep only numerical feature names, exclude NO column
    feature_names = [f for f in feature_names if f != 'NO']
    n_features = len(feature_names)
    
    if n_features == 0:
        # Handle case with no features
        return None, None, None, None, None, None
    if len(X) < 10:
        print(f"⚠️ Small sample size ({len(X)}), GA selection may be unstable")
    
    # Core features only keep existing numerical features
    core_indices = []
    for f in core_features:
        if f in feature_names:
            core_indices.append(feature_names.index(f))
    if not core_indices:
        core_indices = list(range(min(3, n_features)))
        print(f"Warning: Specified core features not found, using default first {len(core_indices)} numerical features as core: {[feature_names[i] for i in core_indices]}")
    
    # Fixed random seed
    if random_seed is not None:
        random.seed(random_seed)
        np.random.seed(random_seed)
    
    # GA parameter configuration (adjusted based on number of numerical features)
    population_size = min(30, n_features * 2)
    ngen = 50
    cxpb = 0.7
    mutpb = 0.15
    
    # Modification point: Ensure maximum features do not exceed 15
    max_features = min(15, int(n_features * 0.8), n_features)
    min_features = max(len(core_indices) + 3, 5) if n_features >= 5 else n_features
    
    # Ensure minimum features do not exceed maximum features
    if min_features > max_features:
        min_features = max_features
    
    print(f"GA feature selection configuration: population size={population_size}, iterations={ngen}, feature selection range={min_features}-{max_features} (numerical features only)")
    
    # Reset DEAP creator
    if 'FitnessMin' in dir(creator):
        del creator.FitnessMin
    if 'Individual' in dir(creator):
        del creator.Individual
    creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
    creator.create("Individual", list, fitness=creator.FitnessMin)
    
    toolbox = base.Toolbox()
    
    # Initialize individual (ensure core numerical features are mandatory)
    def init_individual():
        individual = [0] * n_features
        for idx in core_indices:
            individual[idx] = 1  # Core numerical features forced to be selected
        remaining_needed = random.randint(min_features - len(core_indices), max_features - len(core_indices))
        non_core_indices = [i for i in range(n_features) if i not in core_indices]
        if remaining_needed > len(non_core_indices):
            remaining_needed = len(non_core_indices)
        if non_core_indices and remaining_needed > 0:
            selected_non_core = random.sample(non_core_indices, remaining_needed)
            for idx in selected_non_core:
                individual[idx] = 1
        return creator.Individual(individual)
    
    toolbox.register("individual", init_individual)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual, n=population_size)
    
    # Evaluation function (based on XGBoost numerical feature evaluation)
    def evaluate(individual):
        selected_count = sum(individual)
        if selected_count < min_features or selected_count > max_features:
            return (1e6,)  # Penalize when feature count is invalid
        
        selected_mask = [bool(g) for g in individual]
        X_sel = X[:, selected_mask]  # Select only numerical features
        
        # Use models that can better improve R²
        base_model = XGBRegressor(
            n_estimators=200, 
            max_depth=5, 
            learning_rate=0.05, 
            subsample=0.8,
            colsample_bytree=0.8, 
            random_state=random_seed, 
            verbose=0
        )
        
        try:
            # Calculate R² and accuracy
            cv_r2_scores = cross_val_score(base_model, X_sel, y, cv=5, scoring='r2', n_jobs=-1)
            avg_r2 = cv_r2_scores.mean()
            
            # Calculate accuracy compliance rate
            cv_y_preds = cross_val_predict(base_model, X_sel, y, cv=5, n_jobs=-1)
            cv_relative_error = np.abs(cv_y_preds - y.values) / (y.values + 1e-6)
            cv_accuracy_rate = (cv_relative_error <= 0.15).sum() / len(y)
            
            # Combined objective: prioritize R²≥0.7 and accuracy≥85%
            if avg_r2 >= 0.7 and cv_accuracy_rate >= 0.85:
                # Solutions that meet criteria, prioritize fewer features
                fitness = -avg_r2 - cv_accuracy_rate + selected_count * 0.01
            else:
                # Solutions that don't meet criteria, penalize distance from target
                r2_penalty = max(0, 0.7 - avg_r2) * 10
                accuracy_penalty = max(0, 0.85 - cv_accuracy_rate) * 10
                fitness = r2_penalty + accuracy_penalty + selected_count * 0.01
                
            return (fitness,)
        except Exception as e:
            print(f"GA evaluation error: {str(e)[:30]}...")
            return (1e6,)
    
    toolbox.register("evaluate", evaluate)
    toolbox.register("mate", tools.cxUniform, indpb=0.2)  # Uniform crossover
    toolbox.register("select", tools.selTournament, tournsize=4)  # Tournament selection
    
    # Mutation function (ensure core numerical features are not mutated)
    def mutate(individual):
        for i in range(n_features):
            if i in core_indices:
                individual[i] = 1  # Core numerical features forbidden to mutate to 0
                continue
            if random.random() < mutpb:
                individual[i] = 1 - individual[i]
        
        # Adjust feature count to valid range
        selected_count = sum(individual)
        non_core_indices = [i for i in range(n_features) if i not in core_indices]
        
        if selected_count < min_features:
            need_add = min_features - selected_count
            available_to_add = [i for i in non_core_indices if individual[i] == 0]
            if available_to_add:
                add_indices = random.sample(available_to_add, min(need_add, len(available_to_add)))
                for idx in add_indices:
                    individual[idx] = 1
        elif selected_count > max_features:
            need_remove = selected_count - max_features
            available_to_remove = [i for i in non_core_indices if individual[i] == 1]
            if available_to_remove:
                remove_indices = random.sample(available_to_remove, min(need_remove, len(available_to_remove)))
                for idx in remove_indices:
                    individual[idx] = 0
        
        return (individual,)
    
    toolbox.register("mutate", mutate)
    
    # Start GA optimization
    pop = toolbox.population()
    hof = tools.HallOfFame(1)  # Save best individual
    stats = tools.Statistics(lambda ind: ind.fitness.values)
    stats.register("min", np.min)
    start_time = time.time()
    
    print(f"\nGA feature selection (core numerical features: {[feature_names[i] for i in core_indices]})")
    pop, log = algorithms.eaSimple(
        pop, toolbox, cxpb, mutpb, ngen=ngen, 
        halloffame=hof, stats=stats, verbose=False
    )
    
    # Print GA iteration process
    log_min = log.select("min")
    for gen in range(0, ngen, 10):
        elapsed = time.time() - start_time
        current_min_rmse = log_min[gen] if gen < len(log_min) else log_min[-1]
        print(f"Generation {gen:2d} | Best fitness: {current_min_rmse:.2f} | Time elapsed: {elapsed:.2f}s")
    
    # Extract best features
    best_ind = hof[0]
    best_mask = [bool(g) for g in best_ind]
    if len(best_mask) > X.shape[1]:
        best_mask = best_mask[:X.shape[1]]
    best_X = X[:, best_mask]
    best_names = [name for idx, name in enumerate(feature_names) if best_mask[idx] and idx < len(feature_names)]
    
    # Validate best feature performance
    val_model = XGBRegressor(
        n_estimators=200, max_depth=5, learning_rate=0.05, 
        subsample=0.8, colsample_bytree=0.8, random_state=random_seed
    )
    
    cv_r2 = cross_val_score(val_model, best_X, y, cv=5, scoring='r2').mean()
    cv_mse = -cross_val_score(val_model, best_X, y, cv=5, scoring='neg_mean_squared_error').mean()
    cv_rmse = np.sqrt(cv_mse)
    cv_y_pred = cross_val_predict(val_model, best_X, y, cv=5)
    cv_relative_error = np.abs(cv_y_pred - y.values) / (y.values + 1e-6)
    cv_accuracy_rate = (cv_relative_error <= 0.15).sum() / len(y)
    
    # Print GA results
    print(f"\nGA completed: Selected {len(best_names)} numerical features")
    print(f"Cross-validation metrics | R²: {cv_r2:.3f} | RMSE: {cv_rmse:.2f} | Accuracy compliance rate: {cv_accuracy_rate:.1%}")
    print(f"Selected numerical features: {best_names}")
    
    # Save GA results
    if experiment_dir is not None:
        with open(os.path.join(experiment_dir, "feature_selection", "selected_features.txt"), "w", encoding="utf-8") as f:
            f.write(f"GA feature selection results ({datetime.now().strftime('%Y-%m-%d %H:%M:%S')})\n")
            f.write(f"Experiment random seed: {random_seed}\n")
            f.write(f"Core features: {core_features}\n")
            f.write(f"Total numerical features (after excluding NO): {n_features}\n")
            f.write(f"Selected feature count: {len(best_names)}\n")
            f.write("Selected numerical feature list:\n")
            for idx, feat in enumerate(best_names, 1):
                f.write(f"{idx}. {feat}\n")
            f.write(f"\nCross-validation evaluation metrics:\n")
            f.write(f"R²: {cv_r2:.3f}\n")
            f.write(f"RMSE: {cv_rmse:.2f}\n")
            f.write(f"Accuracy compliance rate (relative error ≤15%): {cv_accuracy_rate:.1%}\n")
        
        np.save(os.path.join(experiment_dir, "feature_selection", "feature_mask.npy"), best_mask)
        
        pd.DataFrame({
            "feature_index": [idx for idx, mask in enumerate(best_mask) if mask],
            "feature_name": best_names
        }).to_csv(
            os.path.join(experiment_dir, "feature_selection", "selected_features.csv"),
            index=False, encoding="utf-8-sig"
        )
        print(f"✅ GA feature selection results saved to: {os.path.join(experiment_dir, 'feature_selection')}")
    
    return best_X, best_names, cv_r2, cv_rmse, best_mask, cv_accuracy_rate

# -------------------------- 4. Model optimization (4:1 split, numerical features only, output detailed metrics) --------------------------
def optimize_models(X, y, feature_names, test_size=0.2, random_seed=None, experiment_dir=None):
    # Keep only numerical feature names, exclude NO column
    feature_names = [f for f in feature_names if f != 'NO']
    if not X.shape[0] == len(y):
        raise ValueError(f"Feature matrix sample count ({X.shape[0]}) does not match target variable sample count ({len(y)})")
    
    # 4:1 train/test split (fixed random seed)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_seed, shuffle=True
    )
    print(f"\nTrain/test split completed | Training set: {X_train.shape[0]} samples, {X_train.shape[1]} numerical features | Test set: {X_test.shape[0]} samples")
    print(f"Split ratio: {X_train.shape[0]}:{X_test.shape[0]} ≈ {X_train.shape[0]/X.shape[0]:.1%}:{X_test.shape[0]/X.shape[0]:.1%}")
    
    # Save test set data
    if experiment_dir is not None:
        test_data = pd.DataFrame(X_test, columns=feature_names)
        test_data['PHRR_true'] = y_test.values
        test_data.to_csv(os.path.join(experiment_dir, "data_splits", "test_set_data.csv"), index=False, encoding="utf-8-sig")
        print(f"Test set data saved to: {os.path.join(experiment_dir, 'data_splits', 'test_set_data.csv')}")
    
    # Model parameter grids (optimized for numerical features, add regularization to prevent overfitting) - Remove SVR model
    param_grids = {
        "Ridge Regression": {"alpha": [0.1, 0.5, 1, 5, 10], "solver": ["auto", "cholesky"], "max_iter": [2000]},
        "Elastic Net Regression": {"alpha": [0.1, 0.5, 1, 2], "l1_ratio": [0.1, 0.3, 0.5, 0.7], "max_iter": [3000], "tol": [1e-4]},
        "Gradient Boosting Regressor": {"n_estimators": [100, 150], "learning_rate": [0.03, 0.05], "max_depth": [3, 4], "subsample": [0.7, 0.8], "min_samples_split": [5, 10], "min_samples_leaf": [3, 5], "random_state": [random_seed]},
        "Random Forest Regressor": {"n_estimators": [100, 150], "max_depth": [4, 5], "min_samples_split": [5, 10], "min_samples_leaf": [3, 5], "max_features": ['sqrt', 0.7], "random_state": [random_seed]},
        "XGBoost": {"n_estimators": [100, 150], "max_depth": [3, 4], "learning_rate": [0.03, 0.05], "subsample": [0.7, 0.8], "colsample_bytree": [0.7, 0.8], "reg_alpha": [0.5, 1], "reg_lambda": [1, 1.5], "random_state": [random_seed]},
        "K-Nearest Neighbors": {"n_neighbors": [3, 4, 5, 6], "weights": ["distance"], "metric": ["manhattan", "euclidean"], "leaf_size": [20, 30]},
        "Adaboost Regressor": {"n_estimators": [50, 100], "learning_rate": [0.05, 0.1], "loss": ["linear", "square"], "random_state": [random_seed]},
        "Catboost Regressor": {"iterations": [100, 150], "depth": [3, 4], "learning_rate": [0.03, 0.05], "subsample": [0.7, 0.8], "l2_leaf_reg": [3, 5], "verbose": [0], "random_state": [random_seed]},
        "Multilayer Perceptron Regressor": {"hidden_layer_sizes": [(50,), (50, 25), (100,)], "activation": ["relu"], "alpha": [0.001, 0.01], "max_iter": [2000], "learning_rate_init": [0.001, 0.0005], "early_stopping": [True], "random_state": [random_seed]}
    }
    
    # Models to optimize (all support numerical feature input) - Remove SVR model
    models = {
        "Ridge Regression": Ridge(),
        "Elastic Net Regression": ElasticNet(),
        "Gradient Boosting Regressor": GradientBoostingRegressor(),
        "Random Forest Regressor": RandomForestRegressor(),
        "XGBoost": XGBRegressor(),
        "K-Nearest Neighbors": KNeighborsRegressor(),
        "Adaboost Regressor": AdaBoostRegressor(),
        "Catboost Regressor": CatBoostRegressor(verbose=0),
        "Multilayer Perceptron Regressor": MLPRegressor()
    }
    
    optimized_models = {}
    qualified_models = {}  # Models with accuracy ≥85% and R²≥0.7
    algo_metrics_list = []  # Algorithm metrics summary
    model_logs = []  # Model optimization logs
    
    # New: Store test set prediction results
    test_predictions = pd.DataFrame()
    test_predictions['true'] = y_test.values
    
    print("\n=== Model optimization (Scoring metric: negative RMSE, Train:Test=4:1, numerical features only) ===")
    print("Note: All models exclude NO sequence column, automatically saved as .pkl files after optimization")
    print("Note: SVR model removed due to high computational cost and parameter sensitivity")
    print("Note: Added regularization parameters to prevent overfitting")
    
    for model_name, base_model in models.items():
        try:
            if model_name not in param_grids:
                print(f"{model_name:<25} | No parameter grid configuration, skip optimization")
                continue
            
            # Grid search optimization (5-fold cross-validation)
            grid_search = GridSearchCV(
                estimator=base_model,
                param_grid=param_grids[model_name],
                cv=5,
                scoring="neg_mean_squared_error",
                n_jobs=-1,
                verbose=0,
                refit=True
            )
            
            start_time = time.time()
            grid_search.fit(X_train, y_train)
            train_time = round(time.time() - start_time, 2)
            
            # Extract best model and parameters
            best_model = grid_search.best_estimator_
            best_params = grid_search.best_params_
            best_cv_rmse = np.sqrt(-grid_search.best_score_)  # Cross-validation RMSE
            
            # Test set prediction and metric calculation
            y_test_pred = best_model.predict(X_test)
            test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
            test_r2 = r2_score(y_test, y_test_pred)
            test_r, test_r_pvalue = pearsonr(y_test.values, y_test_pred)
            test_relative_error = np.abs(y_test_pred - y_test.values) / (y_test.values + 1e-6)
            test_avg_accuracy = 1 - np.mean(test_relative_error)
            test_accuracy_rate = (test_relative_error <= 0.15).sum() / len(y_test)
            
            # Training set metric calculation (for overfitting judgment)
            y_train_pred = best_model.predict(X_train)
            train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
            train_r2 = r2_score(y_train, y_train_pred)
            train_r, train_r_pvalue = pearsonr(y_train.values, y_train_pred)
            
            def check_overfitting(train_r2, test_r2, train_rmse, test_rmse, threshold=0.15):
                """Check if model might be overfitting"""
                r2_diff = abs(train_r2 - test_r2)
                rmse_ratio = test_rmse / train_rmse if train_rmse > 0 else 1
                
                # If training performance is significantly better than test performance, might be overfitting
                if r2_diff > threshold or rmse_ratio > 1.5:
                    return True
                return False
            
            # Check if current model might be overfitting
            is_overfitted = check_overfitting(train_r2, test_r2, train_rmse, test_rmse)
            
            # If model is overfitted, try using simpler model
            if is_overfitted:
                print(f"{model_name:<25} | Possible overfitting detected, trying simplified model...")
                
                # Create simplified version of model
                if model_name == "Random Forest Regressor":
                    simple_model = RandomForestRegressor(
                        n_estimators=50, max_depth=3, min_samples_split=10, 
                        min_samples_leaf=5, random_state=random_seed
                    )
                elif model_name == "XGBoost":
                    simple_model = XGBRegressor(
                        n_estimators=50, max_depth=3, learning_rate=0.03, 
                        subsample=0.7, colsample_bytree=0.7, 
                        reg_alpha=1, reg_lambda=1.5, random_state=random_seed
                    )
                elif model_name == "Gradient Boosting Regressor":
                    simple_model = GradientBoostingRegressor(
                        n_estimators=50, max_depth=3, learning_rate=0.03, 
                        subsample=0.7, min_samples_split=10, 
                        min_samples_leaf=5, random_state=random_seed
                    )
                elif model_name == "Multilayer Perceptron Regressor":
                    simple_model = MLPRegressor(
                        hidden_layer_sizes=(30,), alpha=0.01, max_iter=2000, 
                        learning_rate_init=0.001, early_stopping=True, random_state=random_seed
                    )
                else:
                    # For other models, use default parameters
                    simple_model = clone(base_model)
                    simple_model.set_params(**{k: v[0] for k, v in param_grids[model_name].items() if not isinstance(v, list)})
                
                # Train simplified model
                simple_model.fit(X_train, y_train)
                
                # Re-evaluate simplified model
                y_test_pred_simple = simple_model.predict(X_test)
                test_rmse_simple = np.sqrt(mean_squared_error(y_test, y_test_pred_simple))
                test_r2_simple = r2_score(y_test, y_test_pred_simple)
                test_r_simple, test_r_pvalue_simple = pearsonr(y_test.values, y_test_pred_simple)
                test_relative_error_simple = np.abs(y_test_pred_simple - y_test.values) / (y_test.values + 1e-6)
                test_avg_accuracy_simple = 1 - np.mean(test_relative_error_simple)
                test_accuracy_rate_simple = (test_relative_error_simple <= 0.15).sum() / len(y_test)
                
                # Check if simplified model is still overfitting
                y_train_pred_simple = simple_model.predict(X_train)
                train_rmse_simple = np.sqrt(mean_squared_error(y_train, y_train_pred_simple))
                train_r2_simple = r2_score(y_train, y_train_pred_simple)
                is_overfitted_simple = check_overfitting(train_r2_simple, test_r2_simple, train_rmse_simple, test_rmse_simple)
                
                # If simplified model is not overfitting or performs better, use simplified model
                if not is_overfitted_simple or (test_r2_simple > test_r2 and test_accuracy_rate_simple > test_accuracy_rate):
                    print(f"{model_name:<25} | Using simplified model to solve overfitting")
                    best_model = simple_model
                    best_params = simple_model.get_params()
                    test_rmse = test_rmse_simple
                    test_r2 = test_r2_simple
                    test_r = test_r_simple
                    test_r_pvalue = test_r_pvalue_simple
                    test_relative_error = test_relative_error_simple
                    test_avg_accuracy = test_avg_accuracy_simple
                    test_accuracy_rate = test_accuracy_rate_simple
                    train_rmse = train_rmse_simple
                    train_r2 = train_r2_simple
                    train_r, train_r_pvalue = pearsonr(y_train.values, y_train_pred_simple)
                    is_overfitted = is_overfitted_simple
            
            # Save optimized model information
            optimized_models[model_name] = {
                "model": best_model,
                "best_params": best_params,
                "cv_rmse": best_cv_rmse,
                "train_metrics": {
                    "r": train_r,
                    "r2": train_r2,
                    "rmse": train_rmse,
                    "r_pvalue": train_r_pvalue
                },
                "test_metrics": {
                    "r": test_r,
                    "r2": test_r2,
                    "rmse": test_rmse,
                    "r_pvalue": test_r_pvalue,
                    "avg_accuracy": test_avg_accuracy,
                    "accuracy_rate": test_accuracy_rate,
                    "y_pred": y_test_pred,
                    "y_true": y_test.values,
                    "relative_error": test_relative_error
                },
                "train_time": train_time,
                "is_overfitted": is_overfitted
            }
            
            # Record algorithm metrics
            algo_metrics_list.append({
                "Model Name": model_name,
                "Training Set R": round(train_r, 4),
                "Training Set R²": round(train_r2, 4),
                "Training Set RMSE": round(train_rmse, 4),
                "Test Set R": round(test_r, 4),
                "Test Set R²": round(test_r2, 4),
                "Test Set RMSE": round(test_rmse, 4),
                "Cross-Validation RMSE": round(best_cv_rmse, 4),
                "Test Set Average Accuracy": round(test_avg_accuracy, 4),
                "Test Set Accuracy Compliance Rate": round(test_accuracy_rate, 4),
                "Overfitting": "Yes" if is_overfitted else "No",
                "Training Time (s)": train_time
            })
            
            # Record model logs
            model_logs.append({
                "Optimization Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Model Name": model_name,
                "Best Parameters": str(best_params),
                "Training Set R": round(train_r, 4),
                "Training Set R²": round(train_r2, 4),
                "Training Set RMSE": round(train_rmse, 4),
                "Test Set R": round(test_r, 4),
                "Test Set R²": round(test_r2, 4),
                "Test Set RMSE": round(test_rmse, 4),
                "Cross-Validation RMSE": round(best_cv_rmse, 4),
                "Test Set Average Accuracy": round(test_avg_accuracy, 4),
                "Test Set Accuracy Compliance Rate": round(test_accuracy_rate, 4),
                "Overfitting": "Yes" if is_overfitted else "No",
                "Training Time (s)": train_time,
                "Status": "Success"
            })
            
            # New: Save test set prediction results
            test_predictions[model_name] = y_test_pred
            
            # Determine if criteria met (accuracy compliance rate ≥85% and R²≥0.7 and not overfitting)
            if test_accuracy_rate >= 0.85 and test_r2 >= 0.7 and not is_overfitted:
                qualified_models[model_name] = optimized_models[model_name]
                status_tag = "✅ Qualified"
            else:
                status_tag = "❌ Not qualified"
            
            # Print model results
            print(f"{model_name:<25} | Train R: {train_r:.4f} | Train R²: {train_r2:.4f} | Train RMSE: {train_rmse:.4f}")
            print(f"{'':<25} | Test R: {test_r:.4f} | Test R²: {test_r2:.4f} | Test RMSE: {test_rmse:.4f} | Compliance Rate: {test_accuracy_rate:.1%} | Overfitting: {'Yes' if is_overfitted else 'No'} | {status_tag}")
            
            # Save model file
            if experiment_dir is not None:
                model_filename = f"{model_name.replace(' ', '_').lower()}_{datetime.now().strftime('%H%M%S')}.pkl"
                model_save_path = os.path.join(experiment_dir, "models", model_filename)
                joblib.dump(best_model, model_save_path)
                print(f"   → {model_name} saved to: {model_save_path}")
        
        except Exception as e:
            error_msg = str(e)[:50] + "..." if len(str(e)) > 50 else str(e)
            print(f"{model_name:<25} | Optimization error: {error_msg}")
            model_logs.append({
                "Optimization Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Model Name": model_name,
                "Best Parameters": None,
                "Training Set R": None,
                "Training Set R²": None,
                "Training Set RMSE": None,
                "Test Set R": None,
                "Test Set R²": None,
                "Test Set RMSE": None,
                "Cross-Validation RMSE": None,
                "Test Set Average Accuracy": None,
                "Test Set Accuracy Compliance Rate": None,
                "Overfitting": None,
                "Training Time (s)": None,
                "Status": f"Failed: {error_msg}"
            })
            optimized_models[model_name] = {
                "error": error_msg,
                "status": "failed"
            }
    
    # Save test set prediction results
    if experiment_dir is not None and not test_predictions.empty:
        test_pred_path = os.path.join(experiment_dir, "predictions", "test_set_predictions.csv")
        test_predictions.to_csv(test_pred_path, index=False, encoding="utf-8-sig")
        print(f"\n✅ Test set prediction results saved to: {test_pred_path}")
    
    # Print optimization summary
    print(f"\n=== Model optimization summary ===")
    print(f"Total models: {len(models)} | Successfully optimized: {len([m for m in optimized_models.values() if 'error' not in m])} | Qualified models (≥85% and R²≥0.7 and not overfitting): {len(qualified_models)}")
    
    # Save metrics and logs
    if experiment_dir is not None:
        algo_metrics_df = pd.DataFrame(algo_metrics_list)
        metrics_save_path = os.path.join(experiment_dir, "logs", "algorithm_core_metrics.csv")
        algo_metrics_df.to_csv(metrics_save_path, index=False, encoding="utf-8-sig")
        print(f"\n✅ Algorithm core metrics summary table saved to: {metrics_save_path}")
        
        log_df = pd.DataFrame(model_logs)
        log_save_path = os.path.join(experiment_dir, "logs", "model_optimization_log.csv")
        log_df.to_csv(log_save_path, index=False, encoding="utf-8-sig")
        print(f"✅ Model optimization log saved to: {log_save_path}")
    
    return optimized_models, qualified_models, algo_metrics_list

# -------------------------- 5. 5-fold cross-validation evaluation (numerical features only) --------------------------
def cross_validation_evaluation(X, y, selected_feats, n_splits=5, experiment_dir=None, random_seed=None):
    # Keep only numerical feature names, exclude NO column
    selected_feats = [f for f in selected_feats if f != 'NO']
    if X.shape[0] < n_splits:
        raise ValueError(f"Sample count ({X.shape[0]}) is less than cross-validation folds ({n_splits}), cannot perform effective evaluation")
    if X.shape[1] == 0:
        raise ValueError("No valid numerical features for cross-validation evaluation")
    
    print(f"\n=== 5-fold cross-validation evaluation (Total {n_splits} folds, numerical features only) ===")
    print(f"Evaluation sample count: {X.shape[0]} | Evaluation feature count: {X.shape[1]} | Selected numerical features: {selected_feats}")
    
    # Initialize 5-fold cross-validation (shuffle data)
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=random_seed)
    
    # Models to evaluate (use default values of optimized parameters, add regularization to prevent overfitting) - Remove SVR model
    models = {
        "Ridge Regression": Ridge(alpha=10, max_iter=2000, random_state=random_seed),
        "Elastic Net Regression": ElasticNet(alpha=1, l1_ratio=0.5, max_iter=3000, random_state=random_seed),
        "Gradient Boosting Regressor": GradientBoostingRegressor(n_estimators=100, learning_rate=0.05, max_depth=3, subsample=0.8, min_samples_split=5, min_samples_leaf=3, random_state=random_seed),
        "Random Forest Regressor": RandomForestRegressor(n_estimators=100, max_depth=4, min_samples_split=5, min_samples_leaf=3, max_features='sqrt', random_state=random_seed),
        "XGBoost": XGBRegressor(n_estimators=100, max_depth=3, learning_rate=0.05, subsample=0.8, colsample_bytree=0.8, reg_alpha=0.5, reg_lambda=1, random_state=random_seed),
        "K-Nearest Neighbors": KNeighborsRegressor(n_neighbors=5, weights="distance", metric="manhattan"),
        "Adaboost Regressor": AdaBoostRegressor(n_estimators=100, learning_rate=0.1, loss="square", random_state=random_seed),
        "Catboost Regressor": CatBoostRegressor(iterations=100, depth=3, learning_rate=0.05, subsample=0.8, l2_leaf_reg=3, verbose=0, random_state=random_seed),
        "Multilayer Perceptron Regressor": MLPRegressor(hidden_layer_sizes=(50,), alpha=0.01, max_iter=2000, learning_rate_init=0.001, early_stopping=True, random_state=random_seed)
    }
    
    cv_results = {}  # Cross-validation results
    cv_detail_logs = []  # Detailed logs
    
    # New: Store 5-fold cross-validation prediction results
    cv_predictions = pd.DataFrame()
    cv_predictions['true'] = y.values
    
    for model_name, model in models.items():
        try:
            fold_r = []  # R value for each fold
            fold_r2 = []  # R² value for each fold
            fold_rmse = []  # RMSE value for each fold
            fold_accuracy_rate = []  # Accuracy compliance rate for each fold
            fold_relative_error = []  # Relative error for each fold
            fold_logs = []  # Logs for each fold
            
            # New: Store current model's 5-fold prediction results
            y_cv_pred = np.zeros_like(y.values, dtype=float)
            
            # Iterate through each fold data
            for fold_idx, (train_idx, val_idx) in enumerate(kf.split(X), 1):
                X_train_fold, X_val_fold = X[train_idx], X[val_idx]
                y_train_fold, y_val_fold = y.iloc[train_idx], y.iloc[val_idx]
                
                # Skip folds with insufficient samples
                if len(X_train_fold) < 5:
                    print(f"⚠️ {model_name} fold {fold_idx} training set sample count insufficient ({len(X_train_fold)}), skip this fold")
                    continue
                
                # Train model and predict
                model.fit(X_train_fold, y_train_fold)
                y_val_pred = model.predict(X_val_fold)
                
                # Save current fold prediction results
                y_cv_pred[val_idx] = y_val_pred
                
                # Calculate fold metrics
                r, r_pvalue = pearsonr(y_val_fold.values, y_val_pred)
                r2 = r2_score(y_val_fold, y_val_pred)
                rmse = np.sqrt(mean_squared_error(y_val_fold, y_val_pred))
                relative_error = np.abs(y_val_pred - y_val_fold.values) / (y_val_fold.values + 1e-6)
                accuracy_rate = (relative_error <= 0.15).sum() / len(y_val_fold)
                avg_accuracy = 1 - np.mean(relative_error)
                
                # Save fold results
                fold_r.append(r)
                fold_r2.append(r2)
                fold_rmse.append(rmse)
                fold_accuracy_rate.append(accuracy_rate)
                fold_relative_error.extend(relative_error)
                
                # Record fold logs
                fold_logs.append({
                    "Model Name": model_name,
                    "Fold": fold_idx,
                    "Training Set Sample Count": len(X_train_fold),
                    "Validation Set Sample Count": len(X_val_fold),
                    "R (Correlation Coefficient)": r,
                    "R Significance p-value": r_pvalue,
                    "R² (Coefficient of Determination)": r2,
                    "RMSE (Root Mean Square Error)": rmse,
                    "Average Accuracy": avg_accuracy,
                    "Accuracy Compliance Rate": accuracy_rate,
                    "Status": "Success"
                })
            
            # New: Save current model's 5-fold prediction results
            cv_predictions[model_name] = y_cv_pred
            
            # Handle case with no valid folds
            if len(fold_r) == 0:
                print(f"{model_name:<25} | No valid fold results, cannot calculate summary metrics")
                cv_results[model_name] = {"status": "failed", "error": "No valid fold results"}
                continue
            
            # Calculate summary metrics
            cv_results[model_name] = {
                "r_mean": np.mean(fold_r),
                "r_std": np.std(fold_r),
                "r2_mean": np.mean(fold_r2),
                "r2_std": np.std(fold_r2),
                "rmse_mean": np.mean(fold_rmse),
                "rmse_std": np.std(fold_rmse),
                "accuracy_rate_mean": np.mean(fold_accuracy_rate),
                "accuracy_rate_std": np.std(fold_accuracy_rate),
                "avg_relative_error": np.mean(fold_relative_error),
                "valid_folds": len(fold_r),
                "status": "success"
            }
            
            # Merge logs
            cv_detail_logs.extend(fold_logs)
            
            # Print model cross-validation results
            print(f"{model_name:<25} | R: {np.mean(fold_r):.4f}±{np.std(fold_r):.4f} | "
                  f"R²: {np.mean(fold_r2):.4f}±{np.std(fold_r2):.4f} | "
                  f"RMSE: {np.mean(fold_rmse):.4f}±{np.std(fold_rmse):.4f} | "
                  f"Accuracy Compliance Rate: {np.mean(fold_accuracy_rate):.1%}±{np.std(fold_accuracy_rate):.1%}")
        
        except Exception as e:
            error_msg = str(e)[:50] + "..." if len(str(e)) > 50 else str(e)
            print(f"{model_name:<25} | Cross-validation error: {error_msg}")
            cv_detail_logs.append({
                "Model Name": model_name,
                "Fold": None,
                "Training Set Sample Count": None,
                "Validation Set Sample Count": None,
                "R (Correlation Coefficient)": None,
                "R Significance p-value": None,
                "R² (Coefficient of Determination)": None,
                "RMSE (Root Mean Square Error)": None,
                "Average Accuracy": None,
                "Accuracy Compliance Rate": None,
                "Status": f"Failed: {error_msg}"
            })
            cv_results[model_name] = {"status": "failed", "error": error_msg}
    
    # Save 5-fold cross-validation prediction results
    if experiment_dir is not None and not cv_predictions.empty:
        cv_pred_path = os.path.join(experiment_dir, "predictions", "cv_predictions.csv")
        cv_predictions.to_csv(cv_pred_path, index=False, encoding="utf-8-sig")
        print(f"\n✅ 5-fold cross-validation prediction results saved to: {cv_pred_path}")
    
    # Save cross-validation results
    if cv_results:
        cv_result_list = []
        for model_name, result in cv_results.items():
            if result["status"] == "success":
                cv_result_list.append({
                    "Model Name": model_name,
                    "Valid Folds": result["valid_folds"],
                    "R Mean": round(result["r_mean"], 4),
                    "R Standard Deviation": round(result["r_std"], 4),
                    "R² Mean": round(result["r2_mean"], 4),
                    "R² Standard Deviation": round(result["r2_std"], 4),
                    "RMSE Mean": round(result["rmse_mean"], 4),
                    "RMSE Standard Deviation": round(result["rmse_std"], 4),
                    "Accuracy Compliance Rate Mean": round(result["accuracy_rate_mean"], 4),
                    "Accuracy Compliance Rate Standard Deviation": round(result["accuracy_rate_std"], 4),
                    "Average Relative Error": round(result["avg_relative_error"], 4),
                    "Status": "Success"
                })
            else:
                cv_result_list.append({
                    "Model Name": model_name,
                    "Valid Folds": None,
                    "R Mean": None,
                    "R Standard Deviation": None,
                    "R² Mean": None,
                    "R² Standard Deviation": None,
                    "RMSE Mean": None,
                    "RMSE Standard Deviation": None,
                    "Accuracy Compliance Rate Mean": None,
                    "Accuracy Compliance Rate Standard Deviation": None,
                    "Average Relative Error": None,
                    "Status": f"Failed: {result['error']}"
                })
        
        cv_result_df = pd.DataFrame(cv_result_list)
        if experiment_dir is not None:
            cv_result_path = os.path.join(experiment_dir, "PHRR_cross_validation_results.csv")
        else:
            cv_result_path = "PHRR_cross_validation_results.csv"
        cv_result_df.to_csv(cv_result_path, index=False, encoding="utf-8-sig")
        print(f"\n✅ 5-fold cross-validation results summary saved to: {cv_result_path}")
    
    # Save detailed logs
    if experiment_dir is not None and cv_detail_logs:
        cv_detail_df = pd.DataFrame(cv_detail_logs)
        cv_detail_path = os.path.join(experiment_dir, "logs", "cross_validation_detail_log.csv")
        cv_detail_df.to_csv(cv_detail_path, index=False, encoding="utf-8-sig")
        print(f"✅ Cross-validation detailed log saved to: {cv_detail_path}")
    
    return cv_results
# -------------------------- Main function (add iterative optimization mechanism) --------------------------
def main(random_seed=5):
    print("="*60)
    print(f"===== PHRR Model Evaluation Program (5-fold CV + Numerical Features Only + No Standardization) =====")
    print(f"===== Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} =====")
    print("="*60)
    
    # Initialize experiment directory
    experiment_dir = init_experiment_dir()
    print(f"\nExperiment directory created: {experiment_dir}")
    
    # Load data (numerical features only, no one-hot encoding)
    dataset, target_col, numeric_cols, matrix_cols, encoder = load_data(random_seed)
    if len(dataset) < 10:
        print(f"⚠️ Warning: Small sample size ({len(dataset)}), may affect model stability")
    
    # Feature engineering (numerical feature enhancement only)
    dataset_eng = feature_engineering(dataset, target_col)
    X = dataset_eng.drop(columns=[target_col]).values
    y = dataset_eng[target_col]
    feature_names = dataset_eng.drop(columns=[target_col]).columns.tolist()
    print(f"\nFeature engineering completed | Total numerical features (excluding NO and target column): {X.shape[1]} | Feature list: {feature_names}")
    
    # Key modification: Skip standardization step
    X_final = X  # Use original feature values directly
    print("⚠️ Standardization step skipped, using original feature values for model training and evaluation")
    
    # Iterative optimization until qualified models found or maximum iterations reached
    max_iterations = 3
    best_models = {}
    all_results = {}
    
    for iteration in range(max_iterations):
        print(f"\n=== Iteration {iteration+1} Optimization ===")
        
        # GA feature selection (numerical features only)
        best_X, best_feats, cv_r2, cv_rmse, feature_mask, cv_accuracy_rate = ga_feature_selection(
            X_final, y, feature_names, experiment_dir=experiment_dir, random_seed=random_seed+iteration
        )
        
        # Model optimization (4:1 split, numerical features only)
        optimized_models, qualified_models, algo_metrics_df = optimize_models(
            best_X, y, best_feats, test_size=0.2, random_seed=random_seed+iteration, experiment_dir=experiment_dir
        )
        
        # 5-fold cross-validation evaluation (numerical features only)
        cv_results = cross_validation_evaluation(
            best_X, y, best_feats, n_splits=5, experiment_dir=experiment_dir, random_seed=random_seed+iteration
        )
        
        # Independent validation set evaluation (numerical features only, no standardization)
        validation_data = load_validation_data(numeric_cols, matrix_cols, encoder)
        val_results, val_detail_df = evaluate_on_validation_data(
            optimized_models, validation_data, feature_mask, feature_names, 
            target_col, dataset_eng.drop(columns=[target_col]).columns.tolist(),
            experiment_dir=experiment_dir
        )
        
        # Save current iteration results
        all_results[iteration] = {
            "optimized_models": optimized_models,
            "qualified_models": qualified_models,
            "cv_results": cv_results,
            "val_results": val_results
        }
        
        # Check if there are qualified models
        qualified_models_dict = {}
        for model_name, result in val_results.items():
            if result.get("status") == "success" and result.get("metrics"):
                if result["metrics"].get("r2", 0) >= 0.7 and result["metrics"].get("accuracy_rate", 0) >= 0.85:
                    qualified_models_dict[model_name] = result
        
        if qualified_models_dict:
            print(f"\n✅ Found {len(qualified_models_dict)} qualified models")
            best_models.update(qualified_models_dict)
            break
        else:
            print(f"\n⚠️ Iteration {iteration+1} did not find qualified models, continue trying...")
    
    # If no qualified models, use best model
    if not best_models and val_results:
        print("\n⚠️ No fully qualified models found, using best model")
        # Find model with highest R² and accuracy
        best_model_name = None
        best_score = -1
        for model_name, result in val_results.items():
            if result.get("status") == "success" and result.get("metrics"):
                score = result["metrics"].get("r2", 0) + result["metrics"].get("accuracy_rate", 0)
                if score > best_score:
                    best_score = score
                    best_model_name = model_name
        if best_model_name:
            best_models[best_model_name] = val_results[best_model_name]
    
    # Save final results
    if best_models:
        print(f"\n✅ Final selected qualified models: {list(best_models.keys())}")
        for model_name, result in best_models.items():
            metrics = result["metrics"]
            print(f"{model_name}: R²={metrics.get('r2', 0):.3f}, Accuracy={metrics.get('accuracy_rate', 0):.1%}")
    else:
        print("\n❌ Could not find any qualified models")
    
    # Print experiment completion information
    print("\n" + "="*60)
    print(f"===== Experiment Completion Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} =====")
    print(f"===== All results saved to: {experiment_dir} =====")
    print("="*60)
    
    # Save feature mask and feature names
    np.save(os.path.join(experiment_dir, "feature_mask.npy"), feature_mask)
    joblib.dump(feature_names, os.path.join(experiment_dir, "phrr_train_features.pkl"))
    
    # Return core results
    return {
        "experiment_dir": experiment_dir,
        "optimized_models": optimized_models,
        "cv_results": cv_results,
        "val_results": val_results,
        "best_features": best_feats,
        "best_models": best_models
    }

if __name__ == "__main__":
    main(random_seed=1008)