# -*- coding: utf-8 -*-
"""
Created on Thu Oct  2 14:20:05 2025

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
GA-T5 Stop When Qualified (Default Seed 12345) - With Parameter Optimization · Stable Error-Free Version
"""
import os
import sys

# Set temporary directory to English path
if sys.platform.startswith('win'):
    temp_dir = "C:\\Temp_ML_Project"
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)
    
    os.environ['TMP'] = temp_dir
    os.environ['TEMP'] = temp_dir
    os.environ['JOBLIB_TEMP_FOLDER'] = temp_dir

# Set environment variables
os.environ['PYTHONIOENCODING'] = 'utf-8'
os.environ['PYTHONUTF8'] = '1'

# Your other imports and code...
import numpy as np
import pandas as pd
import joblib, os, argparse, warnings, random, time, shutil
from datetime import datetime
from sklearn.model_selection import train_test_split, cross_val_score, cross_val_predict, GridSearchCV, KFold
from sklearn.metrics import r2_score, mean_squared_error
from scipy.stats import pearsonr

# Models
from sklearn.linear_model import Ridge, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, AdaBoostRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.neural_network import MLPRegressor
from xgboost import XGBRegressor
from catboost import CatBoostRegressor

# Genetic Algorithm
from deap import base, tools, creator, algorithms

# ---------- Utilities ----------
def init_experiment_dir():
    t = datetime.now().strftime("%Y%m%d_%H%M%S")
    d = f"ga_experiment_{t}"
    os.makedirs(d, exist_ok=True)
    return d

def load_data():
    df = pd.read_excel("T5%A1.xlsx")
    target = 'T5%(℃)'
    if 'NO' in df.columns:
        df = df.drop(columns=['NO'])
    X = df.drop(columns=[target])
    y = df[target]
    return X.values, y, X.columns.tolist()

# ---------- Genetic Algorithm Feature Selection ----------
def ga_feature_selection(X, y, feature_names, exp_dir=None, seed=42):
    random.seed(seed); np.random.seed(seed)
    ngen, cxpb, mutpb, pop_size = 12, 0.5, 0.7, 10
    out_num = random.randint(5, 16)
    model_params = {'iterations': 500, 'learning_rate': 0.05, 'depth': 6, 'silent': True, 'random_state': seed}

    def eval_fn(ind, X, y):
        if sum(ind) <= 2:
            return (9999,)
        X_sel = X[:, ind]
        model = CatBoostRegressor(**model_params)
        return (np.mean(-cross_val_score(model, X_sel, y, cv=5, scoring='neg_root_mean_squared_error', n_jobs=-1)),)

    if 'FitnessMin' in dir(creator):
        del creator.FitnessMin, creator.Individual
    creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
    creator.create("Individual", list, fitness=creator.FitnessMin)
    toolbox = base.Toolbox()
    toolbox.register("evaluate", eval_fn, X=X, y=y)
    toolbox.register("mate", tools.cxTwoPoint)

    def mutate(ind, indpb, n_feat):
        mutable = list(range(len(ind)))
        if len(ind) > 1 and mutable and random.random() < indpb:
            ind.pop(random.choice(mutable))
        avail = list(set(range(n_feat)) - set(ind))
        if avail and random.random() < indpb:
            ind.append(random.choice(avail))
        min_s, max_s = 2, n_feat
        if len(ind) < min_s:
            ind.extend(random.sample(list(set(range(n_feat))-set(ind)), min_s-len(ind)))
        elif len(ind) > max_s:
            for v in random.sample(ind, len(ind)-max_s):
                ind.remove(v)
        return ind,

    toolbox.register("mutate", mutate, indpb=0.05, n_feat=X.shape[1])
    toolbox.register("select", tools.selTournament, tournsize=10)

    def init_ind(n_feat, out):
        ind = set(random.sample(range(n_feat), min(out, n_feat)))
        return creator.Individual(list(ind))

    toolbox.register("individual", init_ind, n_feat=X.shape[1], out=out_num)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual, n=pop_size)
    pop = toolbox.population()
    hall = tools.HallOfFame(1)
    algorithms.eaSimple(pop, toolbox, cxpb, mutpb, ngen=ngen, halloffame=hall, verbose=False)
    best = hall[0]
    mask = [i in best for i in range(len(feature_names))]
    X_sel = X[:, mask]
    feats = [feature_names[i] for i, m in enumerate(mask) if m]
    if exp_dir:
        with open(os.path.join(exp_dir, "selected_features.txt"), "w", encoding='utf-8') as f:
            f.write("Selected Features:\n" + "\n".join(f"{i+1}. {feat}" for i, feat in enumerate(feats)))
    return X_sel, feats, mask

# ---------- Parameter Optimization ----------
def optimize_parameters(X_train, y_train, model_name, base_model, param_grid, seed=42):
    print(f"Optimizing {model_name} parameters...")
    start = time.time()
    grid = GridSearchCV(base_model, param_grid, cv=5, scoring='r2', n_jobs=-1, verbose=0)
    grid.fit(X_train, y_train)
    print(f"{model_name} Best R²: {grid.best_score_:.4f}, Time: {time.time()-start:.2f}s")
    return grid.best_estimator_, grid.best_params_, grid.best_score_, time.time()-start

# ---------- Model Evaluation ----------
def evaluate_models(X, y, feature_names, exp_dir=None, seed=42):
    random.seed(seed); np.random.seed(seed)
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=seed)

    # Base models
    base_models = {
        "Ridge": Ridge(max_iter=10000, tol=1e-4, random_state=seed),
        "ElasticNet": ElasticNet(max_iter=10000, tol=1e-4, random_state=seed),
        "RF": RandomForestRegressor(random_state=seed),
        "GBR": GradientBoostingRegressor(random_state=seed),
        "XGB": XGBRegressor(random_state=seed),
        "KNN": KNeighborsRegressor(),
        "Ada": AdaBoostRegressor(random_state=seed),
        "Cat": CatBoostRegressor(silent=True, random_state=seed),
        "MLP": MLPRegressor(max_iter=2000, random_state=seed)
    }

    param_grids = {
        "Ridge": {'alpha': [0.1, 0.5, 1.0, 5.0, 10.0]},
        "ElasticNet": {'alpha': [0.1, 0.5, 1.0], 'l1_ratio': [0.1, 0.5, 0.9]},
        "RF": {'n_estimators': [50, 100, 200], 'max_depth': [None, 10, 20], 'min_samples_split': [2, 5]},
        "GBR": {'n_estimators': [50, 100, 200], 'learning_rate': [0.01, 0.05, 0.1], 'max_depth': [3, 5]},
        "XGB": {'n_estimators': [50, 100, 200], 'learning_rate': [0.01, 0.05, 0.1], 'max_depth': [3, 5]},
        "KNN": {'n_neighbors': [3, 5, 7], 'weights': ['uniform', 'distance'], 'p': [1, 2]},
        "Ada": {'n_estimators': [50, 100, 200], 'learning_rate': [0.01, 0.1, 1.0]},
        "Cat": {'iterations': [100, 200], 'learning_rate': [0.01, 0.05], 'depth': [4, 6]},
        "MLP": {'hidden_layer_sizes': [(50,), (100,)], 'activation': ['relu'], 'alpha': [0.0001, 0.001]}
    }

    cv_res, test_res, param_results = [], [], []
    model_dir = os.path.join(exp_dir, "models")
    os.makedirs(model_dir, exist_ok=True)
    
    # Create folder to save prediction results
    predictions_dir = os.path.join(exp_dir, "predictions")
    os.makedirs(predictions_dir, exist_ok=True)

    # Store CV prediction results for all models
    cv_predictions = pd.DataFrame({"Actual_train": y_tr})
    test_predictions = pd.DataFrame({"Actual_test": y_te})

    for name, base_model in base_models.items():
        try:
            best_model, best_params, best_score, opt_time = optimize_parameters(
                X_tr, y_tr, name, base_model, param_grids[name], seed
            )
            
            # 5-fold cross-validation prediction
            kf = KFold(n_splits=5, shuffle=True, random_state=seed)
            cv_preds = cross_val_predict(best_model, X_tr, y_tr, cv=kf)
            cv_r2 = cross_val_score(best_model, X_tr, y_tr, cv=5, scoring='r2').mean()
            cv_rmse = np.sqrt(mean_squared_error(y_tr, cv_preds))
            cv_acc = (np.abs(cv_preds - y_tr) / (y_tr + 1e-6) <= 0.15).mean()
            cv_corr, _ = pearsonr(y_tr, cv_preds)

            # Test set prediction
            best_model.fit(X_tr, y_tr)
            test_preds = best_model.predict(X_te)
            r2_te = r2_score(y_te, test_preds)
            rmse_te = np.sqrt(mean_squared_error(y_te, test_preds))
            acc_te = (np.abs(test_preds - y_te) / (y_te + 1e-6) <= 0.15).mean()
            test_corr, _ = pearsonr(y_te, test_preds)

            cv_res.append({"Model": name, "CV_R2": cv_r2, "CV_RMSE": cv_rmse, "CV_Acc": cv_acc, "CV_Corr": cv_corr})
            test_res.append({"Model": name, "Test_R2": r2_te, "Test_RMSE": rmse_te, "Test_Acc": acc_te, "Test_Corr": test_corr, "Best_Params": str(best_params)})
            
            # Save model
            joblib.dump(best_model, os.path.join(model_dir, f"{name}.pkl"))
            
            # Save prediction results
            cv_predictions[f"{name}_Pred"] = cv_preds
            test_predictions[f"{name}_Pred"] = test_preds
            
            # Save individual model prediction results
            model_cv_pred = pd.DataFrame({
                "Actual": y_tr, 
                "Predicted": cv_preds,
                "Fold": "CV"
            })
            model_test_pred = pd.DataFrame({
                "Actual": y_te, 
                "Predicted": test_preds,
                "Fold": "Test"
            })
            model_preds = pd.concat([model_cv_pred, model_test_pred])
            model_preds.to_csv(os.path.join(predictions_dir, f"{name}_predictions.csv"), index=False)
            
            print(f"{name:<12} | CV R²={cv_r2:.4f}  Test R²={r2_te:.4f}  Test Acc={acc_te:.1%}")
        except Exception as e:
            print(f"{name:<12} | Error: {e}")
            cv_res.append({"Model": name, "Error": str(e)})
            test_res.append({"Model": name, "Error": str(e)})

    # Save CV and test set prediction results for all models
    cv_predictions.to_csv(os.path.join(predictions_dir, "all_models_cv_predictions.csv"), index=False)
    test_predictions.to_csv(os.path.join(predictions_dir, "all_models_test_predictions.csv"), index=False)

    # Save detailed predictions: only keep successful models
    detailed_results = {"Actual": y_te}
    for name in base_models:
        model_path = os.path.join(model_dir, f"{name}.pkl")
        if os.path.exists(model_path):
            model = joblib.load(model_path)
            detailed_results[f"{name}_Pred"] = model.predict(X_te)
    pd.DataFrame(detailed_results).to_csv(os.path.join(exp_dir, "detailed_predictions.csv"), index=False)

    # Result CSV files
    pd.DataFrame(cv_res).to_csv(os.path.join(exp_dir, "cross_validation_results.csv"), index=False)
    pd.DataFrame(test_res).to_csv(os.path.join(exp_dir, "test_results.csv"), index=False)
    return cv_res, test_res, []

# ---------- Main Function ----------
def main(random_seed=12345):
    print("="*60)
    print("GA-T5 Stop When Qualified · Stable Version")
    print("="*60)
    exp_dir = init_experiment_dir()
    X, y, feat_names = load_data()
    print(f"Loaded data: {X.shape[0]} samples, {X.shape[1]} features")
    R2_TH, ACC_TH = 0.70, 0.85

    for it in range(1, 4):
        seed = random_seed + (it-1)
        print(f"\n>>> Iteration {it}/3 (seed={seed})")
        iter_dir = os.path.join(exp_dir, f"iter_{it}")
        os.makedirs(iter_dir, exist_ok=True)

        X_sel, sel_feats, mask = ga_feature_selection(X, y, feat_names, iter_dir, seed)
        print(f"Feature selection completed: selected {len(sel_feats)} features")
        cv, test, _ = evaluate_models(X_sel, y, sel_feats, iter_dir, seed)

        qualified = [t for t in test if isinstance(t, dict) and t.get("Test_R2", 0) >= R2_TH and t.get("Test_Acc", 0) >= ACC_TH]
        if qualified:
            print(f"✅ Iteration {it} qualified: {len(qualified)} models")
            pd.DataFrame(qualified).to_csv(os.path.join(exp_dir, "qualified_models.csv"), index=False)
            
            # Only keep results from first iteration
            if it > 1:
                # Delete other iteration folders
                for i in range(2, 4):
                    other_iter_dir = os.path.join(exp_dir, f"iter_{i}")
                    if os.path.exists(other_iter_dir):
                        shutil.rmtree(other_iter_dir)
                # Rename first iteration to iter_1
                first_iter_dir = os.path.join(exp_dir, "iter_1")
                if os.path.exists(first_iter_dir):
                    shutil.rmtree(first_iter_dir)
                shutil.move(iter_dir, first_iter_dir)
            break
        else:
            print(f"❌ Iteration {it} not qualified")
            # If it's the last iteration, keep results
            if it == 3:
                # Delete previous iteration folders
                for i in range(1, 3):
                    other_iter_dir = os.path.join(exp_dir, f"iter_{i}")
                    if os.path.exists(other_iter_dir):
                        shutil.rmtree(other_iter_dir)
                # Rename third iteration to iter_1
                first_iter_dir = os.path.join(exp_dir, "iter_1")
                if os.path.exists(first_iter_dir):
                    shutil.rmtree(first_iter_dir)
                shutil.move(iter_dir, first_iter_dir)
    print("="*60)
    print("Experiment completed, results saved in:", exp_dir)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=1008, help='Random seed')
    args = parser.parse_args()
    main(args.seed)