# -*- coding: utf-8 -*-
"""
Created on Thu Oct  2 14:46:15 2025

@author: ma'wei'bin
"""

# =========================  Package Imports  =========================
import pandas as pd
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold, train_test_split
from sklearn.metrics import r2_score, mean_squared_error
import matplotlib.pyplot as plt
import time

# =======================  Read Features (with error tolerance)  =======================
with open('selected_features.txt', 'r', encoding='utf-8') as f:
    features = []
    for line in f:
        line = line.strip()
        # Skip empty lines and lines containing "selected features"
        if not line or 'selected features' in line:
            continue
        if '. ' in line:
            feature_name = line.split('. ')[1].strip()
            features.append(feature_name)
        elif line:  # No serial number, directly feature name
            features.append(line)

# =======================  Read Data  =======================
df = pd.read_excel('T5%A1.xlsx', sheet_name='Sheet1')
# Ensure all features exist in DataFrame
available_features = [f for f in features if f in df.columns]
X = df[available_features]
y = df['T5%(℃)']

print(f"Number of features used: {len(available_features)}")
print(f"Feature list: {available_features}")

# =======================  Model Parameters (original scale)  =======================
params = {'alpha': 1}

# =======================  100 repeats 8:2 + 5-fold (no standardization)  =======================
n_repeats = 100
mean_records = []

# Use current time as random seed base to ensure different runs each time
base_seed = int(time.time())

for i in range(n_repeats):
    # Generate different random seed for each iteration
    current_seed = base_seed + i
    
    # 1. Global 8:2 split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=current_seed)

    # 2. Training set 5-fold cross-validation (validation set average)
    kf = KFold(n_splits=5, shuffle=True, random_state=current_seed)
    cv_r2, cv_rmse = [], []
    for train_idx, val_idx in kf.split(X_train):
        X_tr, X_val = X_train.iloc[train_idx], X_train.iloc[val_idx]
        y_tr, y_val = y_train.iloc[train_idx], y_train.iloc[val_idx]

        model = Ridge(**params, random_state=current_seed, max_iter=10000)
        model.fit(X_tr, y_tr)
        y_val_pred = model.predict(X_val)

        cv_r2.append(r2_score(y_val, y_val_pred))
        cv_rmse.append(np.sqrt(mean_squared_error(y_val, y_val_pred)))

    # 3. Global test set evaluation
    model.fit(X_train, y_train)
    y_te_pred = model.predict(X_test)
    te_r2   = r2_score(y_test, y_te_pred)
    te_rmse = np.sqrt(mean_squared_error(y_test, y_te_pred))

    mean_records.append({
        'Run': i + 1,
        'Seed': current_seed,
        'Mean_5FoldVal_R2': np.mean(cv_r2),
        'Mean_5FoldVal_RMSE': np.mean(cv_rmse),
        'Test_R2': te_r2,
        'Test_RMSE': te_rmse
    })

mean_df = pd.DataFrame(mean_records)

# =======================  100 test set overall statistics  =======================
summary_df = pd.DataFrame({
    'Metric': ['Test_R2', 'Test_RMSE'],
    'Mean': [mean_df['Test_R2'].mean(), mean_df['Test_RMSE'].mean()],
    'Std':  [mean_df['Test_R2'].std(),  mean_df['Test_RMSE'].std()],
    'CV(%)': [
        (mean_df['Test_R2'].std()  / abs(mean_df['Test_R2'].mean()))  * 100,
        (mean_df['Test_RMSE'].std() / mean_df['Test_RMSE'].mean()) * 100
    ]
})

# =======================  Final formula (based on random seed 1008)  =======================
# Use fixed random seed 1008 to train final model
X_train_final, X_test_final, y_train_final, y_test_final = train_test_split(
    X, y, test_size=0.2, random_state=1008)

model_final = Ridge(**params, random_state=1008, max_iter=10000)
model_final.fit(X_train_final, y_train_final)

# Use all data to retrain model for final formula
model_final_full = Ridge(**params, random_state=1008, max_iter=10000)
model_final_full.fit(X, y)

coef = model_final_full.coef_
intercept = model_final_full.intercept_
terms = [f"{intercept:.4f}"] + [f"{c:.4f}*{f}" for c, f in zip(coef, available_features)]
formula_str = "T5% = " + " + ".join(terms)
formula_df = pd.DataFrame({'Ridge Formula (raw features)': [formula_str]})

# Evaluate model performance based on seed 1008
y_pred_final = model_final.predict(X_test_final)
final_r2 = r2_score(y_test_final, y_pred_final)
final_rmse = np.sqrt(mean_squared_error(y_test_final, y_pred_final))

# Add performance based on seed 1008 to summary
seed_1008_perf = pd.DataFrame({
    'Metric': ['Seed_1008_R2', 'Seed_1008_RMSE'],
    'Value': [final_r2, final_rmse]
})

# =======================  Output Excel (mean values only)  =======================
out_file = "T5%_Stability_Results1.xlsx"
with pd.ExcelWriter(out_file, engine='openpyxl') as writer:
    mean_df.to_excel(writer, sheet_name='Mean_Results', index=False)
    summary_df.to_excel(writer, sheet_name='Summary', index=False)
    seed_1008_perf.to_excel(writer, sheet_name='Seed_1008_Performance', index=False)
    formula_df.to_excel(writer, sheet_name='Formula', index=False)

print("\n====== 100 Test Set Statistics (original scale) ======")
print(summary_df.to_string(index=False))
print("\n====== Model Performance Based on Random Seed 1008 =====")
print(f"Test Set R²: {final_r2:.4f}")
print(f"Test Set RMSE: {final_rmse:.4f}")
print("\n====== Final Ridge Formula (Based on Random Seed 1008) ======")
print(formula_str)
print(f"\nResults saved to: {out_file}")

# =======================  Plot Distributions  =======================
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
ax1.hist(mean_df['Test_R2'], bins=20, alpha=0.7, color='skyblue')
ax1.axvline(x=final_r2, color='red', linestyle='--', label=f'Seed 1008 (R²={final_r2:.3f})')
ax1.set_xlabel('Test R²')
ax1.set_ylabel('Frequency')
ax1.set_title('Distribution of Test R² Scores')
ax1.legend()

ax2.hist(mean_df['Test_RMSE'], bins=20, alpha=0.7, color='salmon')
ax2.axvline(x=final_rmse, color='red', linestyle='--', label=f'Seed 1008 (RMSE={final_rmse:.3f})')
ax2.set_xlabel('Test RMSE')
ax2.set_ylabel('Frequency')
ax2.set_title('Distribution of Test RMSE Values')
ax2.legend()
plt.tight_layout()
plt.savefig('performance_distribution.png', dpi=300)
plt.show()