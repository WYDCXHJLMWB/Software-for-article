# -*- coding: utf-8 -*-
"""
Created on Thu Oct  2 14:43:23 2025

@author: ma'wei'bin
"""

# =========================  Package Imports  =========================
import pandas as pd
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold, train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import sys

# =========================  Safe Print Function for Spyder  =========================
def safe_print(message):
    """Print function optimized for Spyder environment, solving encoding issues"""
    try:
        # Direct printing, Spyder usually handles UTF-8 correctly
        print(message)
    except UnicodeEncodeError:
        # Handle encoding error situations
        if isinstance(message, str):
            # Try to replace unencodable characters
            print(message.encode('utf-8', errors='replace').decode('utf-8'))
        else:
            print(str(message).encode('utf-8', errors='replace').decode('utf-8'))
    except Exception as e:
        # Extreme error situations
        try:
            print(f"Output warning: {str(e)} | Content: {message}", file=sys.stderr)
        except:
            pass

# =======================  Data Loading and Cleaning Functions  =======================
def load_data():
    try:
        dataset = pd.read_excel("PHRRa1.xlsx")
        target_col = 'PHRR（Kw/m2）'
        
        # Remove NO sequence column
        if 'NO' in dataset.columns:
            initial_count = len(dataset)
            dataset = dataset.drop(columns=['NO'], errors='ignore')
            safe_print(f"⚠️ NO sequence column detected, removed (original sample count: {initial_count}, after removal: {len(dataset)})")
        else:
            safe_print(f"Original data sample count: {len(dataset)}")
        
        # Target value range filtering
        clean_mask = (dataset[target_col] > 10) & (dataset[target_col] <= 1000)
        dataset = dataset[clean_mask].copy().reset_index(drop=True)
        safe_print(f"Sample count after target value filtering: {len(dataset)}")
        
        # Keep only numerical features
        numeric_cols = dataset.select_dtypes(include=[np.number]).columns.tolist()
        if target_col in numeric_cols:
            numeric_cols.remove(target_col)
        dataset = dataset[numeric_cols + [target_col]].copy()
        safe_print(f"Only numerical features kept, feature list: {numeric_cols}")
        
        # IQR outlier filtering
        pre_iqr_count = len(dataset)
        for col in numeric_cols:
            Q1 = dataset[col].quantile(0.25)
            Q3 = dataset[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            dataset = dataset[(dataset[col] >= lower_bound) & (dataset[col] <= upper_bound)].copy().reset_index(drop=True)
        
        safe_print(f"Sample count after IQR outlier filtering: {len(dataset)} (filtered out {pre_iqr_count - len(dataset)} outlier samples)")
        
        # Missing value imputation (median)
        dataset[numeric_cols] = dataset[numeric_cols].fillna(dataset[numeric_cols].median())
        
        return dataset, target_col, numeric_cols
    except Exception as e:
        safe_print(f"Data loading failed: {str(e)}")
        raise  # Terminate program

# =======================  Feature Engineering Function  =======================
def feature_engineering(data, target_col=None, train_features=None):
    df = data.copy()
    
    # Feature enhancement based on numerical features
    additive_cols = ['PAPP', 'MPP', 'W', 'ZS', 'ADP']
    existing_additive = [col for col in additive_cols if col in df.columns]
    if existing_additive:
        df['total_ad'] = df[existing_additive].sum(axis=1)
        df['additive_ratio'] = df['total_ad'] / (df[existing_additive].max(axis=1) + 1e-6)
    else:
        df['total_ad'] = 0
        df['additive_ratio'] = 0
    
    # Numerical feature ratio calculation
    if 'PAPP' in df.columns and 'total_ad' in df.columns:
        df['PAPP_ratio'] = df['PAPP'] / (df['total_ad'] + 1e-6)
    else:
        df['PAPP_ratio'] = 0
    
    if 'MPP' in df.columns and 'total_ad' in df.columns:
        df['MPP_ratio'] = df['MPP'] / (df['total_ad'] + 1e-6)
    else:
        df['MPP_ratio'] = 0
    
    # Synergist numerical feature processing
    synergist_cols = ['W', 'ZS', 'ADP']
    existing_synergist = [col for col in synergist_cols if col in df.columns]
    if existing_synergist:
        df['synergist_total'] = df[existing_synergist].sum(axis=1)
        if 'W' in df.columns:
            df['W_ratio_in_synergist'] = df['W'] / (df['synergist_total'] + 1e-6)
        else:
            df['W_ratio_in_synergist'] = 0
    else:
        df['synergist_total'] = 0
        df['W_ratio_in_synergist'] = 0
    
    # Numerical feature interaction terms
    if all(col in df.columns for col in ['PAPP', 'MPP', 'W']):
        df['PAPP_MPP_W_interaction'] = df['PAPP'] * df['MPP'] * df['W']
    else:
        df['PAPP_MPP_W_interaction'] = 0
    
    # Numerical feature squared terms
    if 'PAPP' in df.columns:
        df['PAPP_square'] = df['PAPP'] ** 2
    else:
        df['PAPP_square'] = 0
    
    if 'MPP' in df.columns:
        df['MPP_square'] = df['MPP'] ** 2
    else:
        df['MPP_square'] = 0
    
    # Add more feature interactions and transformations
    if all(col in df.columns for col in ['PAPP', 'MPP']):
        df['PAPP_MPP_ratio'] = df['PAPP'] / (df['MPP'] + 1e-6)
    
    if all(col in df.columns for col in ['PAPP', 'W']):
        df['PAPP_W_ratio'] = df['PAPP'] / (df['W'] + 1e-6)
    
    # Add polynomial features
    if 'PAPP' in df.columns:
        df['PAPP_sqrt'] = np.sqrt(df['PAPP'])
    
    if 'MPP' in df.columns:
        df['MPP_sqrt'] = np.sqrt(df['MPP'])
    
    if all(col in df.columns for col in ['ZS', 'total_ad']):
        df['ZS_ratio'] = df['ZS'] / (df['total_ad'] + 1e-6)
    
    if all(col in df.columns for col in ['W', 'total_ad']):
        df['W_ratio'] = df['W'] / (df['total_ad'] + 1e-6)
    if all(col in df.columns for col in ['ADP', 'total_ad']):
        df['ADP_ratio'] = df['ADP'] / (df['total_ad'] + 1e-6)
    
    # Keep only numerical features
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if target_col and target_col in numeric_cols:
        numeric_cols.remove(target_col)
    
    # Align with training set features
    if train_features is not None:
        train_features = [f for f in train_features if f != 'NO' and f in numeric_cols + ([target_col] if target_col else [])]
        for feat in train_features:
            if feat not in df.columns:
                df[feat] = 0
        if target_col and target_col in df.columns:
            df = df[train_features + [target_col]]
        else:
            df = df[train_features]
    
    return df

# =========================  Main Function  =========================
def main():
    # Remove encoding configuration code that causes Spyder errors, Spyder handles encoding automatically
    
    # Data loading and cleaning
    safe_print("Starting data loading and cleaning...")
    dataset, target_col, numeric_cols = load_data()
    
    # Feature engineering
    safe_print("Starting feature engineering...")
    df_eng = feature_engineering(dataset, target_col=target_col)
    
    # Read selected features
    try:
        selected_features_df = pd.read_csv('selected_features.csv')
        selected_features = selected_features_df['feature_name'].tolist()
        safe_print(f"Read {len(selected_features)} features from selected_features.csv")
    except Exception as e:
        safe_print(f"Failed to read feature file: {str(e)}")
        return
    
    # Filter valid features
    available_features = [feat for feat in selected_features if feat in df_eng.columns]
    
    # Filter constant features
    var_threshold = 1e-6
    valid_features = []
    for feat in available_features:
        if df_eng[feat].var() > var_threshold:
            valid_features.append(feat)
        else:
            safe_print(f"Filtered constant feature: {feat} (variance={df_eng[feat].var():.6f}, not used in formula generation)")
    
    # Check if there are valid features
    if not valid_features:
        safe_print("Error: No valid features available for modeling, program terminated")
        return
    
    # Prepare feature matrix and target variable
    X = df_eng[valid_features].copy()
    y = df_eng[target_col].values
    
    safe_print(f"Available feature count: {len(valid_features)}/{len(selected_features)}")
    safe_print(f"Sample count: {X.shape[0]}")
    
    # 100 stability tests
    safe_print("Starting 100 stability tests...")
    mean_records = []
    base_seed = 12  # Base seed
    
    for run in range(1, 101):  # Changed from 151 to 101
        # Generate stable random seed
        stable_seed = base_seed + run * 997
        
        # 8:2 data split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=stable_seed)
        
        # 5-fold cross-validation
        kf = KFold(n_splits=5, shuffle=True, random_state=stable_seed)
        cv_r2, cv_rmse = [], []
        
        for train_idx, val_idx in kf.split(X_train):
            X_tr, X_val = X_train.iloc[train_idx], X_train.iloc[val_idx]
            y_tr, y_val = y_train[train_idx], y_train[val_idx]
            
            model = Ridge(alpha=10, max_iter=2000, solver='auto', random_state=stable_seed)
            model.fit(X_tr, y_tr)
            y_val_pred = model.predict(X_val)
            
            cv_r2.append(r2_score(y_val, y_val_pred))
            cv_rmse.append(np.sqrt(mean_squared_error(y_val, y_val_pred)))
        
        # Test set evaluation
        model = Ridge(alpha=10, max_iter=2000, solver='auto', random_state=stable_seed)
        model.fit(X_train, y_train)
        y_te_pred = model.predict(X_test)
        te_r2 = r2_score(y_test, y_te_pred)
        te_rmse = np.sqrt(mean_squared_error(y_test, y_te_pred))
        
        mean_records.append({
            'Run': run,
            'Seed': stable_seed,
            'Mean_TrainVal_R2': np.mean(cv_r2),
            'Mean_TrainVal_RMSE': np.mean(cv_rmse),
            'Test_R2': te_r2,
            'Test_RMSE': te_rmse
        })
        
        # Print progress
        if run % 10 == 0:
            safe_print(f"Completed {run}/100 stability tests")
    
    mean_df = pd.DataFrame(mean_records)
    
    # Calculate statistical results
    summary_df = pd.DataFrame({
        'Metric': ['Test_R2', 'Test_RMSE'],
        'Mean': [mean_df['Test_R2'].mean(), mean_df['Test_RMSE'].mean()],
        'Std':  [mean_df['Test_R2'].std(),  mean_df['Test_RMSE'].std()],
        'CV(%)': [
            (mean_df['Test_R2'].std()  / abs(mean_df['Test_R2'].mean()))  * 100 if mean_df['Test_R2'].mean() != 0 else np.nan,
            (mean_df['Test_RMSE'].std() / mean_df['Test_RMSE'].mean()) * 100 if mean_df['Test_RMSE'].mean() != 0 else np.nan
        ]
    })
    
    # Save results to Excel
    try:
        out_file = "PHRR_Ridge_Stability_Results.xlsx"
        with pd.ExcelWriter(out_file, engine='openpyxl') as writer:
            mean_df.to_excel(writer, sheet_name='Mean_Results', index=False)
            summary_df.to_excel(writer, sheet_name='Test_Summary', index=False)
        safe_print(f"\nExcel results saved to: {out_file}")
    except Exception as e:
        safe_print(f"Failed to save Excel: {str(e)}, using CSV format instead")
        mean_df.to_csv("Mean_Results.csv", index=False, encoding='utf-8-sig')
        summary_df.to_csv("Test_Summary.csv", index=False, encoding='utf-8-sig')
    
    # Print statistical results
    safe_print("\n" + "="*50)
    safe_print("100 Stability Test Statistical Results")
    safe_print("="*50)
    safe_print(summary_df.to_string(index=False))

if __name__ == "__main__":
    main()