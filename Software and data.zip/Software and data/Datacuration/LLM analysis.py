# -*- coding: utf-8 -*-
"""
Created on Thu Oct  2 12:27:43 2025

@author: ma'wei'bin
"""
import os
import re
import time
import json
import requests
from datetime import datetime
import PyPDF2
import logging
from typing import List, Dict, Any, Optional
import getpass

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Configuration
class Config:
    OUTPUT_DIR = "polymer_processing_temperature_analysis"
    RESULTS_FILE = "processing_temperature_analysis_summary.txt"
    PATTERNS_FILE = "discovered_patterns.json"
    CONCLUSION_FILE = "pp_vs_pvc_processing_temperature_conclusion.txt"
    SUPPORTED_FORMATS = [".txt", ".pdf", ".doc", ".docx"]
    DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"
    DEEPSEEK_MODEL = "deepseek-chat"
    API_TIMEOUT = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 5
    DOCUMENTS_FOLDER_NAME = "documents"
    MAX_CONTENT_LENGTH = 10000
    MAX_PAGES_TO_READ = 30

# Document processing tool
class DocumentProcessor:
    @staticmethod
    def get_documents_folder():
        """Get documents folder path from user input"""
        print("\n📁 Please select how to provide document folder path:")
        print("1. Use default 'documents' folder in current directory")
        print("2. Manually enter folder path")
        print("3. Browse current directory and select folder")
        
        while True:
            choice = input("\nPlease enter your choice (1/2/3): ").strip()
            
            if choice == "1":
                # Use default documents folder
                default_path = os.path.join(os.getcwd(), Config.DOCUMENTS_FOLDER_NAME)
                if os.path.exists(default_path):
                    logger.info(f"Using default documents folder: {default_path}")
                    return default_path
                else:
                    print(f"❌ Default folder '{default_path}' does not exist")
                    continue
                    
            elif choice == "2":
                # Manual input
                while True:
                    manual_path = input("Please enter the complete folder path: ").strip()
                    if manual_path and os.path.exists(manual_path) and os.path.isdir(manual_path):
                        logger.info(f"Using manually entered folder: {manual_path}")
                        return manual_path
                    else:
                        print("❌ Invalid path or folder does not exist, please try again")
                        continue
                        
            elif choice == "3":
                # Browse current directory
                return DocumentProcessor._browse_directory()
                
            else:
                print("❌ Invalid choice, please enter 1, 2, or 3")
                continue

    @staticmethod
    def _browse_directory():
        """Browse and select folder from current directory"""
        current_dir = os.getcwd()
        print(f"\n📂 Current directory: {current_dir}")
        print("Available folders:")
        
        folders = []
        for item in os.listdir(current_dir):
            if os.path.isdir(item) and not item.startswith('.'):
                folders.append(item)
                print(f"  📁 {item}")
        
        if not folders:
            print("No folders found in current directory")
            return DocumentProcessor.get_documents_folder()
        
        while True:
            folder_name = input("\nEnter folder name (or 'back' to go back): ").strip()
            if folder_name.lower() == 'back':
                return DocumentProcessor.get_documents_folder()
            
            if folder_name in folders:
                selected_path = os.path.join(current_dir, folder_name)
                logger.info(f"Selected folder: {selected_path}")
                return selected_path
            else:
                print("❌ Folder not found, please try again")

    @staticmethod
    def load_documents_from_folder():
        documents_path = DocumentProcessor.get_documents_folder()
        documents = []
        logger.info(f"Loading documents from {documents_path} and all its subfolders...")
        
        # First process files in root directory
        for filename in os.listdir(documents_path):
            if filename.startswith('.'):
                continue
            
            file_path = os.path.join(documents_path, filename)
            if os.path.isfile(file_path):
                file_doc = DocumentProcessor._process_single_file(
                    file_path=file_path,
                    filename=filename,
                    parent_folder="Root"
                )
                if file_doc:
                    documents.append(file_doc)
        
        # Then recursively process all subfolders
        for root, dirs, files in os.walk(documents_path):
            if root == documents_path:  # Root directory already processed
                continue
                
            if any(part.startswith('.') for part in root.split(os.sep)):
                continue
            
            relative_folder = os.path.relpath(root, documents_path)
            parent_folder = relative_folder if relative_folder != "." else "Root"

            for filename in files:
                if filename.startswith('.'):
                    continue
                
                file_path = os.path.join(root, filename)
                file_doc = DocumentProcessor._process_single_file(
                    file_path=file_path,
                    filename=filename,
                    parent_folder=parent_folder
                )
                if file_doc:
                    documents.append(file_doc)

        if not documents:
            logger.warning(f"No supported format documents found in {documents_path} and its subfolders")
        else:
            logger.info(f"Successfully loaded {len(documents)} documents")
        return documents, documents_path

    @staticmethod
    def _process_single_file(file_path, filename, parent_folder=None):
        # If it's a folder, recursively process files within it
        if os.path.isdir(file_path):
            logger.info(f"Found folder: {os.path.join(parent_folder, filename)}")
            folder_documents = []
            for sub_filename in os.listdir(file_path):
                if sub_filename.startswith('.'):
                    continue
                sub_file_path = os.path.join(file_path, sub_filename)
                if os.path.isfile(sub_file_path):
                    sub_file_doc = DocumentProcessor._process_single_file(
                        file_path=sub_file_path,
                        filename=sub_filename,
                        parent_folder=os.path.join(parent_folder, filename) if parent_folder else filename
                    )
                    if sub_file_doc:
                        folder_documents.append(sub_file_doc)
            return folder_documents

        # Process single file
        file_ext = os.path.splitext(filename)[1].lower()

        if file_ext not in Config.SUPPORTED_FORMATS:
            logger.warning(f"Skipping unsupported format: {os.path.join(parent_folder, filename)} ({file_ext})")
            return None

        try:
            if file_ext == ".pdf":
                content = DocumentProcessor._read_pdf(file_path)
            elif file_ext in [".doc", ".docx"]:
                content = DocumentProcessor._read_doc(file_path)
            else:
                content = DocumentProcessor._read_text(file_path)

            if len(content.strip()) < 50:
                logger.warning(f"Skipping file with too short content: {os.path.join(parent_folder, filename)}")
                return None

            if len(content) > Config.MAX_CONTENT_LENGTH:
                content = content[:Config.MAX_CONTENT_LENGTH] + "...[Content truncated]"
            
            display_name = os.path.join(parent_folder, filename) if parent_folder else filename
            
            return {
                "filename": display_name,
                "content": content,
                "path": file_path,
                "ext": file_ext,
                "parent_folder": parent_folder
            }

        except Exception as e:
            logger.error(f"Failed to load {os.path.join(parent_folder, filename)}: {str(e)}")
            return None

    @staticmethod
    def _read_pdf(file_path):
        content = []
        try:
            with open(file_path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                if reader.is_encrypted:
                    try:
                        if reader.decrypt(""):
                            logger.info(f"PDF decrypted: {os.path.basename(file_path)}")
                        else:
                            raise Exception("PDF is encrypted and cannot be decrypted")
                    except Exception as decrypt_e:
                        raise Exception(f"PDF decryption failed: {str(decrypt_e)}")
                
                total_pages = min(len(reader.pages), Config.MAX_PAGES_TO_READ)
                for page_idx, page in enumerate(reader.pages[:total_pages], 1):
                    try:
                        text = page.extract_text()
                        if text and text.strip():
                            content.append(f"【Page {page_idx}】\n{text}")
                    except Exception as page_e:
                        logger.warning(f"Failed to read page {page_idx}: {str(page_e)}")
                        continue
                
            if not content:
                raise Exception("PDF has no valid text")
            return "\n\n".join(content)
        except Exception as e:
            raise Exception(f"PDF reading error: {str(e)}")

    @staticmethod
    def _read_doc(file_path):
        try:
            try:
                import docx
                doc = docx.Document(file_path)
                content = [para.text for para in doc.paragraphs if para.text.strip()]
                return "\n".join(content) if content else "Word document content is empty"
            except ImportError:
                return f"[python-docx library installation required]"
        except Exception as e:
            raise Exception(f"Word document reading failed: {str(e)}")

    @staticmethod
    def _read_text(file_path):
        encodings = ['utf-8', 'gbk', 'gb2312', 'latin-1', 'utf-8-sig']
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    content = f.read()
                    if content.strip():
                        return content
            except UnicodeDecodeError:
                continue
            except Exception as e:
                continue
        raise Exception("Unable to recognize encoding or file is empty")

    @staticmethod
    def clean_text(text):
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'[^\w\u4e00-\u9fff\s\.\,\;\:\!\?\(\)\-\+\=\*\/\%\$\#\@\&\"]', ' ', text)
        return text.strip()

# Secure API Key Manager
class SecureAPIKeyManager:
    @staticmethod
    def get_api_key():
        """Safely get API key from user input without displaying it"""
        print("\n🔐 API Key Setup")
        print("=" * 50)
        
        # First check environment variable
        env_key = os.environ.get("DEEPSEEK_API_KEY")
        if env_key:
            print("✅ Found API key in environment variable DEEPSEEK_API_KEY")
            use_env = input("Use this key? (y/n): ").strip().lower()
            if use_env == 'y':
                return env_key
        
        # If not using env variable, get from secure input
        print("\nPlease enter your DeepSeek API key:")
        print("Note: The key will not be displayed on screen for security")
        
        api_key = getpass.getpass("API Key: ")
        
        if not api_key.strip():
            raise ValueError("❌ API key cannot be empty")
        
        # Verify key format (basic check)
        if not api_key.startswith("sk-"):
            print("⚠️  Warning: API key should typically start with 'sk-'")
            continue_anyway = input("Continue anyway? (y/n): ").strip().lower()
            if continue_anyway != 'y':
                raise ValueError("API key entry cancelled")
        
        print("✅ API key accepted (securely stored in memory)")
        return api_key

# Analysis engine (focusing on PP vs PVC processing temperature window comparison)
class AnalysisEngine:
    def __init__(self):
        # Securely get API key
        self.api_key = SecureAPIKeyManager.get_api_key()
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        self._create_output_dir()

    def _create_output_dir(self):
        if not os.path.exists(Config.OUTPUT_DIR):
            os.makedirs(Config.OUTPUT_DIR)
            logger.info(f"Created output directory: {os.path.abspath(Config.OUTPUT_DIR)}")

    def _call_deepseek_api_with_retry(self, messages, max_tokens=2000, temperature=0.3):
        for attempt in range(Config.MAX_RETRIES):
            try:
                payload = {
                    "model": Config.DEEPSEEK_MODEL,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                    "stream": False
                }
                
                logger.info(f"API call attempt {attempt + 1}/{Config.MAX_RETRIES}...")
                response = requests.post(
                    Config.DEEPSEEK_API_URL,
                    headers=self.headers,
                    json=payload,
                    timeout=Config.API_TIMEOUT
                )
                response.raise_for_status()
                result = response.json()
                return result["choices"][0]["message"]["content"]
                
            except requests.exceptions.Timeout:
                logger.warning(f"API call timeout, retrying in {Config.RETRY_DELAY*(attempt+1)} seconds...")
                if attempt < Config.MAX_RETRIES - 1:
                    time.sleep(Config.RETRY_DELAY * (attempt + 1))
                continue
            except requests.exceptions.ConnectionError:
                logger.warning(f"API connection failed, retrying in {Config.RETRY_DELAY*(attempt+1)} seconds...")
                if attempt < Config.MAX_RETRIES - 1:
                    time.sleep(Config.RETRY_DELAY * (attempt + 1))
                continue
            except requests.exceptions.HTTPError as e:
                if e.response.status_code == 401:
                    logger.error("❌ API authentication failed - please check your API key")
                    raise Exception("Invalid API key - please verify and try again")
                else:
                    logger.error(f"API HTTP error: {str(e)}")
                if attempt < Config.MAX_RETRIES - 1:
                    time.sleep(Config.RETRY_DELAY)
                continue
            except Exception as e:
                logger.error(f"API call failed: {str(e)}")
                if attempt < Config.MAX_RETRIES - 1:
                    time.sleep(Config.RETRY_DELAY)
                continue
        
        raise Exception(f"API call failed, reached maximum retry attempts")

    def analyze_single_document(self, document):
        logger.info(f"Analyzing document: {document['filename']}")
        clean_content = DocumentProcessor.clean_text(document["content"])
        truncated_content = clean_content[:Config.MAX_CONTENT_LENGTH]

        # Prompt specifically for processing temperature window
        prompt = f"""
Please strictly analyze the following document content, focusing specifically on the comparison of processing temperature parameters between Polypropylene (PP) and Polyvinyl Chloride (PVC):

【Document Content】
{truncated_content}

【Please accurately extract the following temperature-related data】
1. **PP Processing Temperature Data**:
   - Melting Temperature (Tm) range: ___°C to ___°C
   - Processing Temperature range: ___°C to ___°C
   - Decomposition Temperature range: ___°C to ___°C
   - Specific temperature values (e.g., 180°C, 200-220°C, etc.)

2. **PVC Processing Temperature Data**:
   - Glass Transition Temperature (Tg): ___°C
   - Processing Temperature range: ___°C to ___°C
   - Onset Decomposition Temperature: ___°C
   - Specific temperature values (e.g., 160°C, 170-190°C, etc.)

3. **Processing Temperature Window Comparison**:
   - PP processing temperature window width (upper limit - lower limit): ___°C
   - PVC processing temperature window width: ___°C
   - Which material has a wider processing temperature window? How much wider?

4. **Thermal Stability Comparison**:
   - Difference between PP decomposition temperature and processing temperature: ___°C
   - Difference between PVC decomposition temperature and processing temperature: ___°C
   - Which material has better thermal stability (larger difference)?

5. **Specific Processing Technique Temperatures**:
   - Injection Molding temperature: PP ___°C vs PVC ___°C
   - Extrusion temperature: PP ___°C vs PVC ___°C
   - Blow Molding temperature: PP ___°C vs PVC ___°C

6. **Temperature Impact on Performance**:
   - Does the document mention specific cases of degradation due to excessive temperature?
   - Temperature control precision requirements: PP vs PVC which requires stricter control?

【Analysis Requirements】
- Focus only on temperature-related values and facts, ignore other performance comparisons
- Strictly based on document content, do not add external knowledge
- Record specific temperature values and ranges
- If the document provides multiple temperature values, record all relevant values
- Organize data in table format if possible

Please answer in concise bullet points, focusing on presenting temperature data, within 500 words.
"""

        try:
            messages = [
                {"role": "system", "content": "You are a rigorous polymer processing engineer, specializing in precise extraction and analysis of PP and PVC processing temperature data, strictly based on numerical evidence from documents"},
                {"role": "user", "content": prompt.strip()}
            ]
            result = self._call_deepseek_api_with_retry(messages, max_tokens=1800, temperature=0.1)
            return {
                "filename": document['filename'],
                "full_path": document['path'],
                "analysis": result,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "parent_folder": document['parent_folder']
            }
        except Exception as e:
            logger.error(f"Analysis of {document['filename']} failed: {str(e)}")
            return None

    def generate_final_conclusion(self, all_analyses, documents_path):
        """Generate objective conclusion based on temperature data"""
        if not all_analyses:
            raise Exception("No valid analysis results, cannot generate conclusion")
        
        # Summarize analysis results
        summary_parts = []
        temperature_data = {
            "pp_processing_temp": [],
            "pvc_processing_temp": [],
            "pp_melting_temp": [],
            "pvc_tg_temp": [],
            "pp_decomp_temp": [],
            "pvc_decomp_temp": [],
            "pp_window_width": [],
            "pvc_window_width": []
        }
        
        for a in all_analyses:
            analysis_content = a['analysis'][:800] + "..." if len(a['analysis']) > 800 else a['analysis']
            summary_parts.append(f"【Document: {a['filename']}】\n{analysis_content}")
            
            # Simple temperature data extraction (more complex regex can be used in practice)
            if "°C" in a['analysis'] or "℃" in a['analysis']:
                temp_matches = re.findall(r'(\d+[\s\-]*\d*)\s*[°℃]C', a['analysis'])
                if temp_matches:
                    temperature_data["pp_processing_temp"].extend([t for t in temp_matches if "PP" in a['analysis']])
                    temperature_data["pvc_processing_temp"].extend([t for t in temp_matches if "PVC" in a['analysis']])
        
        summary = "\n\n".join(summary_parts)

        # Conclusion generation prompt based on temperature data
        prompt = f"""
Based on the temperature data analysis results from the following {len(all_analyses)} documents, please write a professional conclusion about the comparison of PP and PVC processing temperature windows:

【Document Temperature Data Analysis Summary】
{summary}

【Writing Requirements - Focus on Temperature Window Comparison】
1. **Data Summary Table**:
   First create a comparison table containing the following:
   | Parameter | Polypropylene (PP) | Polyvinyl Chloride (PVC) | Advantage |
   |-----------|-------------------|--------------------------|-----------|
   | Melting Temp/Glass Transition Temp | [Value range]°C | [Value range]°C | [PP/PVC] |
   | Typical Processing Temp Range | [Value range]°C | [Value range]°C | [PP/PVC] |
   | Onset Decomposition Temp | [Value range]°C | [Value range]°C | [PP/PVC] |
   | Processing Temp Window Width | [Value]°C | [Value]°C | [PP/PVC] |
   | Thermal Stability Margin | [Value]°C | [Value]°C | [PP/PVC] |

2. **Processing Temperature Window Analysis**:
   - PP processing temperature window: What is the average width calculated from document data? °C
   - PVC processing temperature window: What is the average width calculated from document data? °C
   - Which material has a wider processing window? How much wider in percentage?

3. **Thermal Stability Comparison**:
   - How much higher is PP decomposition temperature typically than processing temperature? °C
   - How much higher is PVC decomposition temperature typically than processing temperature? °C
   - What is the impact of this temperature difference on processing safety?

4. **Process Adaptability**:
   - Based on temperature window, which material is more suitable for wide temperature range processing?
   - Which material requires stricter temperature control precision? Why?

5. **Specific Evidence Citation**:
   - Cite specific temperature values from documents to support each conclusion
   - Indicate which documents provide the most reliable temperature data

6. **Final Conclusion**:
   - Clearly answer: Is PP's processing temperature window wider than PVC's?
   - If yes, how much wider? (Provide specific value range)
   - What does this advantage mean in actual processing?

【Important】All conclusions must be strictly based on temperature data from documents, no speculation. If data is insufficient, please clearly indicate.

Please write in engineering technical report style, focusing on data comparison, within 1200 words.
"""

        try:
            messages = [
                {"role": "system", "content": "You are a senior engineer in polymer processing field, skilled in comparing material processing performance based on temperature data, your conclusions are strictly based on numerical evidence"},
                {"role": "user", "content": prompt.strip()}
            ]
            conclusion = self._call_deepseek_api_with_retry(messages, max_tokens=2500, temperature=0.1)
            
            # Add data statistics summary
            structured_conclusion = self._add_temperature_summary(conclusion, temperature_data, all_analyses)
            return structured_conclusion
        except Exception as e:
            logger.error(f"Conclusion generation failed: {str(e)}")
            return "Unable to generate final conclusion: API call failed"

    def _add_temperature_summary(self, conclusion, temperature_data, all_analyses):
        """Add temperature data statistics summary"""
        total_docs = len(all_analyses)
        
        # Simple data statistics
        temp_stats = "## Temperature Data Statistics Summary\n\n"
        temp_stats += f"- Total documents analyzed: {total_docs}\n"
        
        for key, values in temperature_data.items():
            if values:
                if 'pp' in key:
                    material = "PP"
                elif 'pvc' in key:
                    material = "PVC"
                else:
                    material = "General"
                
                temp_stats += f"- {material} {key.replace('_', ' ')}: Found {len(values)} data points\n"
        
        temp_stats += f"\n## Analysis Conclusion (PP vs PVC Processing Temperature Window Comparison)\n\n"

        integrity_statement = f"""
## Academic Integrity Statement

### Analysis Overview
- Total documents analyzed: {total_docs}
- Analysis time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- Analysis focus: Precise comparison of PP and PVC processing temperature windows

### Research Methodology Description
1. Focus on extracting specific temperature values (°C) from documents
2. All conclusions strictly based on temperature data provided in documents
3. Special attention to processing temperature range, decomposition temperature, temperature window width
4. Using numerical comparison rather than qualitative description

### Data Limitations
- Validity of conclusions depends on completeness and accuracy of temperature data in documents
- Different documents may use different testing methods and conditions
- Recommended to verify with original document data
"""
        
        return integrity_statement + "\n\n" + temp_stats + conclusion

    def save_results(self, all_analyses, conclusion, documents_path):
        """Save analysis results"""
        try:
            # Save individual analysis reports
            report_path = os.path.join(Config.OUTPUT_DIR, Config.RESULTS_FILE)
            with open(report_path, "w", encoding="utf-8") as f:
                f.write(f"# PP vs PVC Processing Temperature Window Comparison Analysis Report\n")
                f.write(f"Generation time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Document source: {documents_path}\n")
                f.write(f"Documents analyzed: {len(all_analyses)}\n")
                f.write("="*80 + "\n\n")
                
                f.write("## Analysis Summary\n")
                f.write("This report focuses on comparing processing temperature parameters of Polypropylene (PP) and Polyvinyl Chloride (PVC), particularly processing temperature window width.\n\n")
                
                # Group by document
                folder_groups = {}
                for analysis in all_analyses:
                    folder_name = analysis.get('parent_folder', 'Independent files')
                    if folder_name not in folder_groups:
                        folder_groups[folder_name] = []
                    folder_groups[folder_name].append(analysis)
                
                for folder_name, analyses in folder_groups.items():
                    if folder_name != 'Independent files':
                        f.write(f"## Folder: {folder_name}\n")
                    
                    for i, analysis in enumerate(analyses, 1):
                        f.write(f"### {i}. {analysis['filename']}\n")
                        f.write(f"File path: {analysis['full_path']}\n")
                        f.write(f"Analysis time: {analysis['timestamp']}\n")
                        f.write("**Temperature Data Analysis Results:**\n")
                        f.write(f"{analysis['analysis']}\n")
                        f.write("\n" + "-"*60 + "\n\n")

            # Save final conclusion
            if conclusion:
                conclusion_path = os.path.join(Config.OUTPUT_DIR, Config.CONCLUSION_FILE)
                with open(conclusion_path, "w", encoding="utf-8") as f:
                    f.write(conclusion)
                logger.info(f"Final conclusion saved to: {os.path.abspath(conclusion_path)}")

            logger.info(f"Individual analysis reports saved to: {os.path.abspath(report_path)}")
            
        except Exception as e:
            logger.error(f"Failed to save results: {str(e)}")

# Main function
def main():
    print("="*80)
    print("    PP vs PVC Processing Temperature Window Comparison Analysis Tool    ")
    print("="*80)
    print("Focus analysis: Processing temperature range, temperature window width, thermal stability comparison")
    print("="*80)
    
    try:
        # 1. Load documents
        print("\n📁 Loading documents...")
        documents, documents_path = DocumentProcessor.load_documents_from_folder()
        
        # Flatten potentially nested document lists (due to folder processing)
        flat_documents = []
        for doc in documents:
            if isinstance(doc, list):  # If it's a list returned by folder processing
                flat_documents.extend(doc)
            else:
                flat_documents.append(doc)
        
        documents = flat_documents
        
        if not documents:
            print("❌ No documents found, please ensure supported format files exist in the documents folder")
            return

        print(f"✅ Successfully loaded {len(documents)} documents (including files in folders)")

        # 2. Initialize analysis engine
        print("\n🔧 Initializing analysis engine...")
        analyzer = AnalysisEngine()

        # 3. Analyze documents one by one
        all_analyses = []
        print(f"\n📈 Starting analysis of {len(documents)} documents...")
        print("Focus extraction: Melting temperature, processing temperature, decomposition temperature, temperature window data")
        print("-"*60)
        
        successful_count = 0
        for i, doc in enumerate(documents, 1):
            print(f"\n[{i}/{len(documents)}] Analyzing: {doc['filename']}")
            analysis = analyzer.analyze_single_document(doc)
            if analysis:
                all_analyses.append(analysis)
                successful_count += 1
                print(f"✅ Analysis successful ({successful_count}/{len(documents)})")
                
                # Check if contains temperature data
                if "°C" in analysis['analysis'] or "℃" in analysis['analysis']:
                    print("   📊 Contains temperature data")
            else:
                print(f"❌ Analysis failed")
            
            time.sleep(2)

        # 4. Generate final conclusion
        if successful_count > 0:
            print("\n🔍 Generating final conclusion based on temperature data...")
            final_conclusion = analyzer.generate_final_conclusion(all_analyses, documents_path)
        else:
            final_conclusion = "⚠️ All document analyses failed, cannot generate conclusion"

        # 5. Save results
        print("\n💾 Saving analysis results...")
        analyzer.save_results(all_analyses, final_conclusion, documents_path)

        # 6. Display summary
        print("\n" + "="*80)
        print("📋 Analysis Completion Summary")
        print("="*80)
        print(f"Total documents: {len(documents)}")
        print(f"Successful analysis: {successful_count}")
        print(f"Failed analysis: {len(documents) - successful_count}")
        
        # Count documents containing temperature data
        temp_docs_count = sum(1 for a in all_analyses if "°C" in a['analysis'] or "℃" in a['analysis'])
        print(f"Contains temperature data: {temp_docs_count}")
        
        if final_conclusion and len(final_conclusion) > 100:
            print(f"\n✅ Conclusion generated, contains detailed temperature window comparison analysis")
        print("\n" + "="*80)

        print("\n🎉 Analysis completed! Temperature comparison results saved to output directory.")
        print(f"📁 Output directory: {os.path.abspath(Config.OUTPUT_DIR)}")

    except Exception as e:
        print(f"\n❌ Program error: {str(e)}")
        logger.exception("Program execution exception")

if __name__ == "__main__":
    main()
