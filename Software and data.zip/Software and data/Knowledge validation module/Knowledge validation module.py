# -*- coding: utf-8 -*-
"""
Created on Thu Oct  2 15:34:52 2025

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Flame Retardant Formulation Evaluation System - Binary Classification Version (Reasonable/Unreasonable only)
"""
import os
import sys
import time
import gc
import logging
import json
import random
import re
import warnings

import pandas as pd
import numpy as np
import torch

from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling
)
from torch.utils.data import Dataset
from sklearn.model_selection import train_test_split
from sklearn.utils.class_weight import compute_class_weight

os.environ["CUDA_VISIBLE_DEVICES"] = ""
torch.set_num_threads(4)
warnings.filterwarnings("ignore")

# ---------- Path Configuration ----------
TRAINING_DATA_PATHS = [
    r"C:\Users\ma'wei'bin\Desktop\Polymer Composite Machine Learning Processing Parameters\Thermal Stability Data\June New Attempt\0620\Material Formulation Annotation Template phrr.xlsx",
    r"C:\Users\ma'wei'bin\Desktop\Polymer Composite Machine Learning Processing Parameters\Thermal Stability Data\June New Attempt\0620\Material Formulation Annotation Template T5%.xlsx"
]
QWEN_MODEL_PATH   = r"C:\Users\ma'wei'bin\Desktop\Polymer Composite Machine Learning Processing Parameters\Thermal Stability Data\June New Attempt\0620\modelscope\hub\models\qwen\Qwen1___5-0___5B-Chat"
PROJECT_DIR       = r"D:\Flame Retardant Formulation Evaluation Project"
FINE_TUNED_MODEL_DIR = os.path.join(PROJECT_DIR, "fine_tuned_model")
os.makedirs(PROJECT_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(os.path.join(PROJECT_DIR, "train_binary.log"), encoding='utf-8', delay=False)
    ]
)
logger = logging.getLogger(__name__)

FLAME_RETARDANT_KEYWORDS = ["APP", "MPP", "PAPP", "DBDE","AHP", "AAPP", "PAPP1"]

# ---------- Data Processing ----------
def load_and_preprocess_data(file_paths):
    all_data = []
    for file_path in file_paths:
        try:
            xl  = pd.ExcelFile(file_path)
            df  = pd.read_excel(file_path, sheet_name=xl.sheet_names[0])
            # Only keep explicitly labeled samples
            df  = df[df.iloc[:, -2].astype(str).str.contains("Reasonable|Unreasonable", na=False)]
            for _, row in df.iterrows():
                if pd.isna(row.iloc[0]) or str(row.iloc[0]) == '':
                    continue
                features = []
                for col_idx, col_name in enumerate(df.columns[2:-2]):   # Feature columns
                    val = row.iloc[col_idx + 2]
                    if pd.notna(val) and val != 0 and val != '':
                        features.append(f"{col_name}:{val}")
                input_text = "，".join(features)

                # Single-label binary classification
                raw_label  = str(row.iloc[-2])
                label      = "Unreasonable" if "Unreasonable" in raw_label else "Reasonable"
                training_text = f"Formulation Components: {input_text} -> Evaluation Result: {label}"
                all_data.append(training_text)
        except Exception as e:
            logger.error(f"Failed to read {file_path}: {e}")
            continue

    # Negative sample enhancement
    pos = [s for s in all_data if "Reasonable" in s and "Unreasonable" not in s]
    neg = [s for s in all_data if "Unreasonable" in s]
    if len(neg) == 0:
        logger.warning("No negative samples, cannot enhance")
        return pos
    factor = max(1, len(pos) // len(neg) + 3)
    all_data = pos + neg * factor
    random.shuffle(all_data)
    logger.info(f"Enhanced samples: {len(all_data)} (Negative ×{factor})")
    return all_data

# ---------- Dataset ----------
class FormulaDataset(Dataset):
    def __init__(self, encodings):
        self.encodings = encodings
    def __getitem__(self, idx):
        return {k: torch.tensor(v[idx]) for k, v in self.encodings.items()}
    def __len__(self):
        return len(self.encodings['input_ids'])

# ---------- Weighted DataCollator ----------
class WeightedDataCollator(DataCollatorForLanguageModeling):
    def __init__(self, tokenizer, class_weights):
        super().__init__(tokenizer=tokenizer, mlm=False)
        self.class_weights = class_weights
        self.neg_id = tokenizer.encode("Unreasonable", add_special_tokens=False)[0]
    def __call__(self, features):
        batch = super().__call__(features)
        weights = []
        for lbl in batch['labels']:
            weights.append(self.class_weights[1] if self.neg_id in lbl else self.class_weights[0])
        batch['class_weights'] = torch.tensor(weights, dtype=torch.float)
        return batch

# ---------- Weighted Trainer ----------
class WeightedTrainer(Trainer):
    def __init__(self, pad_token_id, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.pad_token_id = pad_token_id
    def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        weights = inputs.pop("class_weights")
        labels  = inputs.get("labels")
        outputs = model(**inputs)
        logits  = outputs.logits
        shift_logits = logits[..., :-1, :].contiguous().view(-1, logits.size(-1))
        shift_labels = labels[..., 1:].contiguous().view(-1)
        loss_fct = torch.nn.CrossEntropyLoss(reduction='none')
        loss = loss_fct(shift_logits, shift_labels)
        weight_exp = weights.unsqueeze(1).expand(-1, labels.size(1) - 1).contiguous().view(-1)
        loss = loss * weight_exp.to(loss.device)
        mask = shift_labels.ne(self.pad_token_id)
        loss = loss.masked_select(mask).mean()
        return (loss, outputs) if return_outputs else loss

# ---------- Binary Classification Post-processing ----------
def binary_decode(raw: str) -> str:
    return "Unreasonable" if "Unreasonable" in raw else "Reasonable"

# ---------- Training ----------
def fine_tune_supervised(train_paths, model_path, project_dir):
    logger.info("Starting binary classification fine-tuning...")
    train_texts = load_and_preprocess_data(train_paths)
    if not train_texts:
        logger.error("No training data"); return None, None
    train_texts, eval_texts = train_test_split(train_texts, test_size=0.1, random_state=42)

    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        model_path, trust_remote_code=True, torch_dtype=torch.float32, low_cpu_mem_usage=True
    )

    # Class weights
    labels = [1 if "Unreasonable" in t else 0 for t in train_texts]
    weights = compute_class_weight('balanced', classes=np.array([0, 1]), y=np.array(labels))
    weights[1] *= 3
    class_weights = torch.tensor(weights, dtype=torch.float)
    logger.info(f"Weights Reasonable={weights[0]:.2f} Unreasonable={weights[1]:.2f}")

    def encode_texts(texts):
        encodings = tokenizer(texts, truncation=True, padding=True, max_length=512, return_tensors="pt")
        encodings['labels'] = encodings['input_ids'].clone()
        return encodings

    train_dataset = FormulaDataset(encode_texts(train_texts))
    eval_dataset  = FormulaDataset(encode_texts(eval_texts))

    training_args = TrainingArguments(
        output_dir=os.path.join(project_dir, "output"),
        overwrite_output_dir=True,
        num_train_epochs=15,
        per_device_train_batch_size=4,
        per_device_eval_batch_size=4,
        learning_rate=1.5e-5,
        eval_steps=50,
        save_steps=200,
        warmup_steps=50,
        logging_dir=os.path.join(project_dir, "logs"),
        logging_steps=10,
        eval_strategy="steps",
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        fp16=False,
        dataloader_pin_memory=False,
        report_to="none",
    )

    data_collator = WeightedDataCollator(tokenizer, class_weights)
    trainer = WeightedTrainer(
        pad_token_id=tokenizer.pad_token_id,
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        tokenizer=tokenizer,
        data_collator=data_collator,
    )
    trainer.train()
    trainer.save_model(FINE_TUNED_MODEL_DIR)
    tokenizer.save_pretrained(FINE_TUNED_MODEL_DIR)
    logger.info(f"Training completed ✅ Model saved: {FINE_TUNED_MODEL_DIR}")
    return FINE_TUNED_MODEL_DIR, tokenizer

# ---------- Evaluation ----------
def evaluate_in_batches(csv_path, model, tokenizer, batch_size=50, start_from=0):
    base_name = os.path.splitext(os.path.basename(csv_path))[0]
    result_file_path = os.path.join(PROJECT_DIR, f"Binary Evaluation Results_{base_name}.csv")
    results = []
    df = pd.read_csv(csv_path)
    total = len(df)
    for start_idx in range(start_from, total, batch_size):
        end_idx = min(start_idx + batch_size, total)
        logger.info(f"Batch {start_idx+1}-{end_idx} / {total}")
        for idx in range(start_idx, end_idx):
            row = df.iloc[idx]
            features = [f"{col}:{row[col]}" for col in df.columns if pd.notna(row[col]) and row[col] != 0 and row[col] != '']
            input_text = "，".join(features)

            prompt = f"""Please analyze the rationality of the following flame retardant formulation based on flame retardant expertise.

Expertise rules:
1. The formulation is rational when it contains at least one of these flame retardants: ammonium polyphosphate (APP), melamine polyphosphate (MPP), piperazine pyrophosphate (PAPP), aluminum hypophosphite (AHP), allylamine polyphosphate (AAPP), or poly(diallyldimethylammonium) polyphosphate (PAPP1)
2. If decabromodiphenyl oxide (DBDE) is present, it must occur together with antimony trioxide (Sb2O3), otherwise the formulation is unreasonable
3. If no flame retardant is present, the formulation is unreasonable

Formulation Components: {input_text}

Please output only one word: Reasonable or Unreasonable
Answer:"""

            inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=512)
            with torch.no_grad():
                outs = model.generate(
                    inputs.input_ids,
                    attention_mask=inputs.attention_mask,
                    max_length=inputs.input_ids.shape[1] + 4,
                    temperature=0.3,
                    top_p=0.8,
                    do_sample=False,
                    num_return_sequences=1,
                    pad_token_id=tokenizer.eos_token_id,
                )
            generated = tokenizer.decode(outs[0], skip_special_tokens=True)
            pred = binary_decode(generated.split("Answer:")[-1])

            # Apply flame retardant rules
            has_flame_retardant = any(k in input_text for k in FLAME_RETARDANT_KEYWORDS)
            has_dbde = "DBDE" in input_text
            has_sb2o3 = "Sb2O3" in input_text
            
            # Rule 1: No flame retardant -> Unreasonable
            if not has_flame_retardant:
                pred = "Unreasonable"
            # Rule 2: DBDE without Sb2O3 -> Unreasonable
            elif has_dbde and not has_sb2o3:
                pred = "Unreasonable"
                
            results.append({"Formulation": input_text, "Evaluation Result": pred})

        pd.DataFrame(results).to_csv(result_file_path, index=False, encoding='utf-8-sig')
        gc.collect()
    logger.info(f"Evaluation completed ✅ Results: {result_file_path}")
    return results

# ---------- Main Entry ----------
if __name__ == "__main__":
    logger.info("=" * 60)
    logger.info("Flame Retardant Formulation Binary Classification System Starting")
    logger.info("=" * 60)

    if os.path.exists(FINE_TUNED_MODEL_DIR):
        logger.info("Loading existing fine-tuned model...")
        tokenizer = AutoTokenizer.from_pretrained(FINE_TUNED_MODEL_DIR, trust_remote_code=True)
        model     = AutoModelForCausalLM.from_pretrained(FINE_TUNED_MODEL_DIR)
    else:
        logger.info("Model not found, starting training...")
        _, tokenizer = fine_tune_supervised(TRAINING_DATA_PATHS, QWEN_MODEL_PATH, PROJECT_DIR)
        model = AutoModelForCausalLM.from_pretrained(FINE_TUNED_MODEL_DIR)

    csv_file = r"C:\Users\ma'wei'bin\Desktop\Polymer Composite Machine Learning Processing Parameters\Thermal Stability Data\June New Attempt\0620\Big Model Formulation Check.csv"
    if os.path.exists(csv_file):
        evaluate_in_batches(csv_file, model, tokenizer, batch_size=200)
    else:
        logger.warning(f"CSV does not exist: {csv_file}")