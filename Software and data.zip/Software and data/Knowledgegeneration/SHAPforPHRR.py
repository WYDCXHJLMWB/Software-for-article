# -*- coding: utf-8 -*-
"""
Created on Thu Oct  2 14:07:11 2025

@author: ma'wei'bin
"""

# -*- coding: utf-8 -*-
"""
Elastic Net SHAP Analysis (selected_features.csv version)
Process: Cleaning + Enhancement → Full 4-Equal Quantile Analysis → Train-Test Split → Training Set SHAP
Always use pd.cut only, never report Bin labels error
"""
import os
import sys
import numpy as np
import pandas as pd
import joblib
import shap
import matplotlib.pyplot as plt
from datetime import datetime
from sklearn.model_selection import train_test_split
import warnings
import traceback
warnings.filterwarnings('ignore')

# ---------- Configuration ----------
TRAIN_TEST_SPLIT_SEED = 1008
TEST_SIZE = 0.2
TARGET_COL = 'PHRR（Kw/m2）'
HEATMAP_MAX_SAMPLES = 200
SELECTED_FEATURES_FILE = 'selected_features.csv'
RAW_DATA_FILE = 'PHRRa1.xlsx'
MODEL_FILE = 'phrr_model1.pkl'
# ---------------------------

# Create a safe output function
def safe_print(message):
    """Use system standard output to directly write bytes, avoid encoding issues"""
    try:
        if isinstance(message, str):
            # Ensure string is encoded as UTF-8 bytes
            sys.stdout.buffer.write(message.encode('utf-8') + b'\n')
        else:
            # For non-string objects, convert to string
            sys.stdout.buffer.write(str(message).encode('utf-8') + b'\n')
        sys.stdout.buffer.flush()
    except Exception as e:
        # If standard output fails, try using standard error output
        try:
            if isinstance(message, str):
                sys.stderr.buffer.write(message.encode('utf-8') + b'\n')
            else:
                sys.stderr.buffer.write(str(message).encode('utf-8') + b'\n')
            sys.stderr.buffer.flush()
        except:
            # If all methods fail, do nothing
            pass

plt.rcParams["figure.dpi"] = 300
plt.rcParams['font.size'] = 12
plt.rc('font', family='Times New Roman')

# ------------------------------------------------------------------
# 1. Load Assets
# ------------------------------------------------------------------
def load_assets():
    # Check if files exist
    if not os.path.exists(MODEL_FILE):
        safe_print(f'❌ Model file does not exist: {MODEL_FILE}')
        return None, None, None
        
    if not os.path.exists(SELECTED_FEATURES_FILE):
        safe_print(f'❌ Feature file does not exist: {SELECTED_FEATURES_FILE}')
        return None, None, None
        
    if not os.path.exists(RAW_DATA_FILE):
        safe_print(f'❌ Data file does not exist: {RAW_DATA_FILE}')
        return None, None, None
    
    try:
        safe_print("Loading model...")
        model = joblib.load(MODEL_FILE)
        safe_print(f'✅ Loaded model: {MODEL_FILE} (Type: {type(model).__name__})')
        
        safe_print("Loading feature file...")
        selected_df = pd.read_csv(SELECTED_FEATURES_FILE)
        selected_names = selected_df['feature_name'].tolist()
        safe_print(f'✅ Loaded selected features: {SELECTED_FEATURES_FILE}, total {len(selected_names)} features')
        safe_print(f'Feature list: {selected_names}')
        
        safe_print("Loading raw data...")
        raw_df = pd.read_excel(RAW_DATA_FILE)
        safe_print(f'✅ Loaded raw data: {RAW_DATA_FILE}, shape: {raw_df.shape}')
        safe_print(f'Data columns: {list(raw_df.columns)}')
        
        return model, selected_names, raw_df
    except Exception as e:
        safe_print(f'❌ Error loading assets: {str(e)}')
        traceback.print_exc()
        return None, None, None

# ------------------------------------------------------------------
# 2. Data Cleaning: NO, numerical, target filtering, IQR
# ------------------------------------------------------------------
def clean_data(df):
    if df is None or df.empty:
        safe_print('❌ Clean data: Input data is empty')
        return None
        
    safe_print("Starting data cleaning...")
    data = df.copy()
    
    # Check if target column exists
    if TARGET_COL not in data.columns:
        safe_print(f'❌ Target column {TARGET_COL} not in data')
        safe_print(f'Data columns: {list(data.columns)}')
        return None
        
    if 'NO' in data.columns:
        data = data.drop(columns=['NO'])
        safe_print("Removed NO column")
        
    numeric_cols = data.select_dtypes(include=[np.number]).columns.tolist()
    safe_print(f'Numerical columns: {numeric_cols}')
    
    if TARGET_COL in numeric_cols:
        numeric_cols.remove(TARGET_COL)
        
    data = data[numeric_cols + [TARGET_COL]].copy()
    safe_print(f'Processed data shape: {data.shape}')
    
    # Filter target column outliers
    mask = (data[TARGET_COL] > 10) & (data[TARGET_COL] <= 1000)
    data = data[mask].reset_index(drop=True)
    safe_print(f'ℹ️ Sample count after target value filtering: {len(data)}')
    
    # IQR filtering
    pre_cnt = len(data)
    for col in numeric_cols:
        Q1, Q3 = data[col].quantile(0.25), data[col].quantile(0.75)
        IQR = Q3 - Q1
        low, high = Q1 - 1.5 * IQR, Q3 + 1.5 * IQR
        data = data[(data[col] >= low) & (data[col] <= high)].reset_index(drop=True)
        
    safe_print(f'ℹ️ Sample count after IQR filtering: {len(data)} (filtered out {pre_cnt - len(data)})')
    return data

# ------------------------------------------------------------------
# 3. Feature Engineering
# ------------------------------------------------------------------
def feature_engineering(df):
    if df is None or df.empty:
        safe_print('❌ Feature engineering: Input data is empty')
        return None
        
    safe_print("Starting feature engineering...")
    data = df.copy()
    
    # Record original columns
    original_cols = list(data.columns)
    safe_print(f'Original columns: {original_cols}')
    
    # Additives
    additive_cols = ['PAPP', 'MPP', 'W', 'ZS', 'ADP']
    exist = [c for c in additive_cols if c in data.columns]
    safe_print(f'Existing additive columns: {exist}')
    
    if exist:
        data['total_ad'] = data[exist].sum(axis=1)
        data['additive_ratio'] = data['total_ad'] / (data[exist].max(axis=1) + 1e-6)
        safe_print("Added additive-related features")
    else:
        data['total_ad'] = 0
        data['additive_ratio'] = 0
        safe_print("No additive columns found, using default values")
        
    # Ratios
    if 'PAPP' in data.columns:
        data['PAPP_ratio'] = data['PAPP'] / (data['total_ad'] + 1e-6)
    else:
        data['PAPP_ratio'] = 0
        
    if 'MPP' in data.columns:
        data['MPP_ratio'] = data['MPP'] / (data['total_ad'] + 1e-6)
    else:
        data['MPP_ratio'] = 0
    
    # Synergists
    synergist_cols = ['W', 'ZS', 'ADP']
    exist_syn = [c for c in synergist_cols if c in data.columns]
    safe_print(f'Existing synergist columns: {exist_syn}')
    
    if exist_syn:
        data['synergist_total'] = data[exist_syn].sum(axis=1)
        if 'W' in data.columns:
            data['W_ratio_in_synergist'] = data['W'] / (data['synergist_total'] + 1e-6)
        else:
            data['W_ratio_in_synergist'] = 0
        safe_print("Added synergist-related features")
    else:
        data['synergist_total'] = 0
        data['W_ratio_in_synergist'] = 0
        safe_print("No synergist columns found, using default values")
        
    # Interactions/Squares/Square roots
    if all(c in data.columns for c in ['PAPP', 'MPP', 'W']):
        data['PAPP_MPP_W_interaction'] = data['PAPP'] * data['MPP'] * data['W']
    else:
        data['PAPP_MPP_W_interaction'] = 0
        
    if 'PAPP' in data.columns:
        data['PAPP_square'] = data['PAPP'] ** 2
        data['PAPP_sqrt'] = np.sqrt(data['PAPP'])
    else:
        data['PAPP_square'] = 0
        data['PAPP_sqrt'] = 0
        
    if 'MPP' in data.columns:
        data['MPP_square'] = data['MPP'] ** 2
        data['MPP_sqrt'] = np.sqrt(data['MPP'])
    else:
        data['MPP_square'] = 0
        data['MPP_sqrt'] = 0
    
    # More ratios
    if all(c in data.columns for c in ['PAPP', 'MPP']):
        data['PAPP_MPP_ratio'] = data['PAPP'] / (data['MPP'] + 1e-6)
    else:
        data['PAPP_MPP_ratio'] = 0
        
    if all(c in data.columns for c in ['ZS', 'total_ad']):
        data['ZS_ratio'] = data['ZS'] / (data['total_ad'] + 1e-6)
    else:
        data['ZS_ratio'] = 0
        
    if all(c in data.columns for c in ['W', 'total_ad']):
        data['W_ratio'] = data['W'] / (data['total_ad'] + 1e-6)
    else:
        data['W_ratio'] = 0
        
    if all(c in data.columns for c in ['ADP', 'total_ad']):
        data['ADP_ratio'] = data['ADP'] / (data['total_ad'] + 1e-6)
    else:
        data['ADP_ratio'] = 0
    
    # Keep numerical columns only
    num_cols = data.select_dtypes(include=[np.number]).columns.tolist()
    if TARGET_COL in num_cols:
        num_cols.remove(TARGET_COL)
    
    safe_print(f'Data shape after feature engineering: {data.shape}')
    safe_print(f'New features: {set(data.columns) - set(original_cols)}')
    
    return data[num_cols + [TARGET_COL]]

# ------------------------------------------------------------------
# 4. Full 4-Equal Quantile Analysis (only use pd.cut, never error)
# ------------------------------------------------------------------
def full_quantile_analysis(model, X_all, y_all, selected_names, save_dir):
    if X_all is None or y_all is None or len(X_all) == 0:
        safe_print('❌ Quantile analysis: Input data is empty')
        return None, None
        
    os.makedirs(save_dir, exist_ok=True)
    safe_print(f'\n📊 Full data 4-equal quantile analysis, results directory: {save_dir}')
    
    safe_print(f'Original X_all shape: {X_all.shape}')
    safe_print(f'Selected features: {selected_names}')
    
    X_all_aligned = X_all.reindex(columns=selected_names, fill_value=0.)
    safe_print(f'Aligned X_all shape: {X_all_aligned.shape}')
    
    # Quick SHAP (only for quantile analysis)
    try:
        safe_print("Calculating SHAP values...")
        explainer = shap.KernelExplainer(lambda x: model.predict(x), X_all_aligned.values, feature_names=selected_names)
        shap_values = explainer.shap_values(X_all_aligned.values)
        if shap_values.ndim == 1:
            shap_values = shap_values.reshape(-1, 1)
        safe_print(f'SHAP values shape: {shap_values.shape}')
    except Exception as e:
        safe_print(f'❌ SHAP calculation failed: {str(e)}')
        traceback.print_exc()
        return X_all_aligned, y_all

    # 4-equal quantile analysis (all using pd.cut)
    sv_df = pd.DataFrame(shap_values, columns=selected_names)
    for feat in selected_names:
        if feat not in X_all_aligned.columns:
            safe_print(f'⚠️ Feature {feat} not in data, skipping')
            continue
            
        val = X_all_aligned[feat]
        if val.nunique() <= 1:
            safe_print(f'⚠️ Feature {feat} has only one unique value, skipping')
            continue
            
        try:
            tmp = pd.DataFrame({'value': val, 'shap': sv_df[feat]})
            tmp['q'] = pd.cut(tmp['value'], bins=4, labels=['Q1', 'Q2', 'Q3', 'Q4'])
            stat = (tmp.groupby('q', observed=True)
                      .agg(value_mean=('value', 'mean'), shap_mean=('shap', 'mean'), count=('shap', 'count'))
                      .reset_index())
            stat.to_csv(os.path.join(save_dir, f'{feat}_quantile.csv'), encoding='utf-8-sig', index=False)
            
            # Plot
            plt.figure(figsize=(6, 4))
            colors = ['#f4c2c2' if v > 0 else '#b0b0b0' for v in stat['shap_mean']]   # Pink / Gray
            plt.bar(stat['q'], stat['shap_mean'], color=colors)
            plt.title(f'{feat} Quantile SHAP Mean')
            plt.ylabel('Mean SHAP')
            plt.tight_layout()
            safe = feat.replace('/', '_').replace('*', '_').replace(':', '_')
            plt.savefig(os.path.join(save_dir, f'{safe}_quantile.png'), dpi=300)
            plt.close()
            safe_print(f'✅ Processed feature: {feat}')
        except Exception as e:
            safe_print(f'⚠️ Quantile analysis failed for feature {feat}: {str(e)}')
            continue
            
    safe_print(f'   Quantile analysis results → {save_dir}')
    return X_all_aligned, y_all

# ------------------------------------------------------------------
# 5. Train-Test Split and Save
# ------------------------------------------------------------------
def split_and_save(X_all, y_all, selected_names):
    if X_all is None or y_all is None or len(X_all) == 0:
        safe_print('❌ Train-test split: Input data is empty')
        return None, None
        
    safe_print("Splitting training and test sets...")
    X_train, X_test, y_train, y_test = train_test_split(
        X_all, y_all, test_size=TEST_SIZE, random_state=TRAIN_TEST_SPLIT_SEED
    )
    safe_print(f'✅ Training set: {X_train.shape[0]} samples, features: {X_train.shape[1]}')
    
    os.makedirs('training_set_output', exist_ok=True)
    # With target column
    train_with_target = X_train.copy()
    train_with_target[TARGET_COL] = y_train.values
    train_with_target.to_csv('training_set_output/training_set_with_target.csv', index=False, encoding='utf-8-sig')
    
    # Without target column
    X_train.to_csv('training_set_output/X_train_final.csv', index=False, encoding='utf-8-sig')
    
    # Labels
    y_train.to_csv('training_set_output/y_train.csv', index=False, encoding='utf-8-sig')
    safe_print('📁 Training set saved to training_set_output/')
    
    return X_train, y_train

# ------------------------------------------------------------------
# 6. Training Set SHAP and Plotting
# ------------------------------------------------------------------
def run_shap(model, X_train, feature_names):
    if X_train is None or len(X_train) == 0:
        safe_print('❌ SHAP analysis: Input data is empty')
        return None
        
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    out_dir = f'shap_result_{ts}'
    os.makedirs(out_dir, exist_ok=True)
    safe_print(f'\n📊 Training set SHAP analysis started, results directory: {out_dir}')

    # Explainer
    try:
        safe_print("Creating LinearExplainer...")
        explainer = shap.LinearExplainer(model, X_train, feature_names=feature_names)
        safe_print("✅ LinearExplainer created successfully")
    except Exception as e:
        safe_print(f'⚠️ LinearExplainer failed, switching to KernelExplainer: {str(e)}')
        try:
            safe_print("Creating KernelExplainer...")
            explainer = shap.KernelExplainer(model.predict, X_train, feature_names=feature_names)
            safe_print("✅ KernelExplainer created successfully")
        except Exception as e2:
            safe_print(f'❌ KernelExplainer also failed: {str(e2)}')
            traceback.print_exc()
            return out_dir

    # SHAP values
    try:
        safe_print("Calculating SHAP values...")
        shap_values = explainer.shap_values(X_train)
        if isinstance(shap_values, list):
            shap_values = np.array(shap_values)
        if shap_values.ndim == 1:
            shap_values = shap_values.reshape(-1, 1)
            
        safe_print(f'SHAP values shape: {shap_values.shape}')
            
        pd.DataFrame(shap_values, columns=feature_names).to_csv(
            os.path.join(out_dir, 'shap_values.csv'), index=False, encoding='utf-8-sig'
        )
        safe_print("✅ SHAP values calculated and saved successfully")
    except Exception as e:
        safe_print(f'❌ SHAP value calculation failed: {str(e)}')
        traceback.print_exc()
        return out_dir

    # Plots
    safe_print("Generating SHAP plots...")
    _plot_shap(explainer, shap_values, X_train, feature_names, out_dir)
    return out_dir

# ------------------------------------------------------------------
# 7. SHAP Plot Collection
# ------------------------------------------------------------------
def _plot_shap(explainer, sv, X, feat_names, out_dir):
    # ---- Unified style ----
    plt.rcParams["figure.dpi"] = 300
    plt.rcParams['font.size'] = 12
    plt.rc('font', family='Times New Roman')
    plt.rcParams['axes.unicode_minus'] = False
    os.makedirs(out_dir, exist_ok=True)
    
    if not isinstance(X, pd.DataFrame):
        X = pd.DataFrame(X, columns=feat_names)
        
    if sv.ndim == 1:
        sv = sv.reshape(-1, 1)

    # 1. Feature importance bar chart (pink)
    try:
        safe_print("Generating feature importance bar chart...")
        feature_importance = np.abs(sv).mean(axis=0)
        sorted_idx = np.argsort(feature_importance)
        fig, ax = plt.subplots(figsize=(10, 8))
        ax.barh(range(len(feat_names)), feature_importance[sorted_idx], color='pink')
        ax.set_yticks(range(len(feat_names)))
        ax.set_yticklabels(np.array(feat_names)[sorted_idx])
        ax.set_xlabel('Mean Absolute SHAP values')
        ax.set_title('Feature importance')
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, 'feature_importance_bar.png'), dpi=300)
        plt.close('all')
        safe_print('  → Bar chart saved')
    except Exception as e:
        safe_print(f'⚠️ Bar chart failed: {str(e)}')
        traceback.print_exc()

    # 2. Beeswarm plot (gray→pink continuous gradient, colorbar on right)
    try:
        safe_print("Generating beeswarm plot...")
        from matplotlib.colors import LinearSegmentedColormap
        fig, ax = plt.subplots(figsize=(10, 8))

        feature_importance = np.abs(sv).mean(axis=0)
        sorted_idx = np.argsort(feature_importance)[::-1]

        # No white continuous gradient: gray → pink
        cmap = LinearSegmentedColormap.from_list('gray_pink', ['#808080', '#ffc0cb'])
        vmax = np.abs(sv).max() * 1.05
        norm = plt.Normalize(vmin=-vmax, vmax=vmax)

        for i, idx in enumerate(sorted_idx):
            y_pos = np.random.normal(i, 0.15, sv.shape[0])
            ax.scatter(sv[:, idx], y_pos,
                       c=sv[:, idx], s=22, alpha=0.8,
                       cmap=cmap, norm=norm, edgecolors='none')

        ax.set_yticks(range(len(sorted_idx)))
        ax.set_yticklabels(np.array(feat_names)[sorted_idx])
        ax.set_xlabel('SHAP values')
        ax.set_ylabel('Features')
        ax.set_title('SHAP values distribution')
        ax.axvline(x=0, color='black', linestyle='-', alpha=0.4)

        # Continuous colorbar on right
        sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
        sm.set_array([])
        fig.colorbar(sm, ax=ax, orientation='vertical', pad=0.02,
                     fraction=0.05, aspect=30, label='SHAP value')

        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, 'beeswarm.png'), dpi=300)
        plt.close('all')
        safe_print('  → Beeswarm plot saved')
    except Exception as e:
        safe_print(f'⚠️ Beeswarm plot failed: {str(e)}')
        traceback.print_exc()

    # 3. Waterfall plot (sample 0)
    try:
        safe_print("Generating waterfall plot...")
        fig, ax = plt.subplots(figsize=(12, 8))
        sample_idx = 0
        sorted_idx = np.argsort(sv[sample_idx])
        cumulative = explainer.expected_value
        values = [cumulative]
        for i in sorted_idx:
            cumulative += sv[sample_idx, i]
            values.append(cumulative)
        bar_colors = ['pink' if sv[sample_idx, i] >= 0 else 'gray' for i in sorted_idx]
        ax.bar(range(len(values)), values, color='lightgray')
        for i, idx in enumerate(sorted_idx):
            ax.bar(i + 1, sv[sample_idx, idx],
                   bottom=values[i], color=bar_colors[i])
        ax.axhline(y=explainer.expected_value, color='black', linestyle='--', alpha=0.7)
        ax.set_xlabel('Features')
        ax.set_ylabel('SHAP value')
        ax.set_title(f'SHAP waterfall (sample #{sample_idx+1})')
        ax.set_xticks(range(1, len(sorted_idx)+1))
        ax.set_xticklabels(np.array(feat_names)[sorted_idx], rotation=45)
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, 'waterfall.png'), dpi=300)
        plt.close('all')
        safe_print('  → Waterfall plot saved')
    except Exception as e:
        safe_print(f'⚠️ Waterfall plot failed: {str(e)}')
        traceback.print_exc()

    # 4. Heatmap (RdBu_r)
    try:
        safe_print("Generating heatmap...")
        n_heat = min(HEATMAP_MAX_SAMPLES, sv.shape[0])
        fig, ax = plt.subplots(figsize=(12, 10))
        feature_importance = np.abs(sv[:n_heat]).mean(axis=0)
        sorted_idx = np.argsort(feature_importance)[::-1]
        im = ax.imshow(sv[:n_heat, sorted_idx].T, aspect='auto', cmap='RdBu_r')
        fig.colorbar(im, ax=ax, label='SHAP value')
        ax.set_xlabel('Samples')
        ax.set_ylabel('Features')
        ax.set_yticks(range(len(sorted_idx)))
        ax.set_yticklabels(np.array(feat_names)[sorted_idx])
        ax.set_title('SHAP heatmap')
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, 'heatmap.png'), dpi=300)
        plt.close('all')
        safe_print('  → Heatmap saved')
    except Exception as e:
        safe_print(f'⚠️ Heatmap failed: {str(e)}')
        traceback.print_exc()

    # 5. Dependence plots (gray/pink)
    dep_dir = os.path.join(out_dir, 'dependence')
    os.makedirs(dep_dir, exist_ok=True)
    safe_print("Generating dependence plots...")
    for feat in feat_names:
        try:
            if feat not in X.columns:
                continue
                
            feat_idx = feat_names.index(feat)
            fig, ax = plt.subplots(figsize=(10, 8))
            colors = ['pink' if v >= 0 else 'gray' for v in sv[:, feat_idx]]
            ax.scatter(X[feat], sv[:, feat_idx],
                       c=colors, s=30, alpha=0.7)
            ax.set_xlabel(feat)
            ax.set_ylabel('SHAP value')
            ax.set_title(f'SHAP dependence plot: {feat}')
            ax.axhline(y=0, color='black', linestyle='-', alpha=0.3)
            fig.tight_layout()
            safe = feat.replace('/', '_').replace('*', '_').replace(':', '_')
            fig.savefig(os.path.join(dep_dir, f'{safe}.png'), dpi=300)
            plt.close('all')
        except Exception as e:
            safe_print(f'⚠️ Dependence plot {feat} failed: {str(e)}')
            continue
    safe_print(f'   Dependence plots → {dep_dir}')

# ------------------------------------------------------------------
# 9. Main Entry (New process: 4-equal quantile analysis → Split → SHAP)
# ------------------------------------------------------------------
if __name__ == '__main__':
    try:
        safe_print('=' * 60)
        safe_print('Elastic Net SHAP Analysis (selected_features.csv version)')
        safe_print('=' * 60)
        
        # Check if necessary files exist
        if not all(os.path.exists(f) for f in [MODEL_FILE, SELECTED_FEATURES_FILE, RAW_DATA_FILE]):
            safe_print('❌ Please ensure all files exist:')
            safe_print(f'   - {MODEL_FILE}')
            safe_print(f'   - {SELECTED_FEATURES_FILE}')
            safe_print(f'   - {RAW_DATA_FILE}')
            sys.exit(1)
        
        model, selected_names, raw_df = load_assets()
        if model is None or selected_names is None or raw_df is None:
            safe_print('❌ Failed to load assets, program exiting')
            sys.exit(1)

        # 1. Cleaning + Enhancement
        safe_print('\n🔧 Data cleaning in progress...')
        clean_df = clean_data(raw_df)
        if clean_df is None or clean_df.empty:
            safe_print('❌ Data cleaning failed, program exiting')
            sys.exit(1)
            
        safe_print('🔧 Feature engineering in progress...')
        eng_df = feature_engineering(clean_df)
        if eng_df is None or eng_df.empty:
            safe_print('❌ Feature engineering failed, program exiting')
            sys.exit(1)
            
        X_all = eng_df.drop(columns=[TARGET_COL])
        y_all = eng_df[TARGET_COL]
        safe_print(f'Final data shape: X={X_all.shape}, y={y_all.shape}')

        # 2. Full 4-equal quantile analysis (only using pd.cut)
        quantile_dir = 'quantile_analysis_full'
        X_all, y_all = full_quantile_analysis(model, X_all, y_all, selected_names, quantile_dir)
        if X_all is None:
            safe_print('❌ Quantile analysis failed, program exiting')
            sys.exit(1)

        # 3. Train-test split and save
        safe_print('\n📊 Splitting training set...')
        X_train, y_train = split_and_save(X_all, y_all, selected_names)
        if X_train is None:
            safe_print('❌ Training set split failed, program exiting')
            sys.exit(1)

        # 4. Training set SHAP
        safe_print('\n📈 Running SHAP analysis...')
        out_dir = run_shap(model, X_train.values, selected_names)

        safe_print('\n' + '=' * 60)
        safe_print('✅ All tasks completed!')
        safe_print(f'📊 Full 4-equal quantile analysis results: {quantile_dir}')
        safe_print('📁 Training set saved: training_set_output/')
        safe_print(f'📊 Training set SHAP results: {out_dir}')
        safe_print('=' * 60)
        
    except Exception as exc:
        safe_print(f'❌ Program exception: {str(exc)}')
        # Use traceback.format_exc() to get complete exception information
        exc_info = traceback.format_exc()
        safe_print(f'Detailed error information: {exc_info}')